import { fork, all } from 'redux-saga/effects';
import homeSaga from '../views/pages/home/saga';
import headerSaga from '../views/layout/header/saga';
import registerSaga from '../views/pages/register/saga';
import loginSaga from '../views/components/login/saga';
import solutionSaga from '../views/components/explore/saga';
import solutionexSaga from '../views/components/explore-path/saga';
import subscribeSaga from '../views/pages/subscribe/saga';
import accountSaga from '../views/components/account/saga';
import subscriptionListSaga from '../views/components/subscriptionDetails/saga';
import partnerSaga from '../views/components/partnerProducts/saga';
import adminSubSaga from '../views/pages/admin-subscriptions/saga';
import adminLogin from '../views/pages/admin-login/saga';
import adminCaSubSaga from '../views/pages/admin-subscriptions-cancel/saga';
import adminLeadSaga from '../views/pages/admin-leads/saga';
import adminTradeSaga from '../views/pages/admin-trade/saga';

import partnerDetailSaga from '../views/components/partnerDetails/saga';
import pdpSaga from '../views/pages/pdp/saga';
import adminPartnerLeads from '../views/pages/admin-partner-leads/saga';
import partners from '../views/components/partners/saga';
import traderegisterSaga from '../views/components/blog/saga';
export default function* rootSaga() {
  yield all([
    fork(homeSaga),
    fork(headerSaga),
    fork(loginSaga),
    fork(solutionSaga),
    fork(registerSaga),
    fork(subscribeSaga),
    fork(accountSaga),
    fork(subscriptionListSaga),
    fork(partnerSaga),
    fork(adminSubSaga),
    fork(adminCaSubSaga),
    fork(adminLeadSaga),
    fork(adminTradeSaga),
    fork(partnerDetailSaga),
    fork(pdpSaga),
    fork(solutionexSaga),
    fork(adminLogin),
    fork(adminPartnerLeads),
    fork(partners),
    fork(traderegisterSaga),
    
  ]);
}

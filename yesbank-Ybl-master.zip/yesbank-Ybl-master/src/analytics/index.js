export const onLoadTrack = (data) => {
  try {
    digitalData.pageInfo.pageName = data.pageName;
    digitalData.userInfo.loginStatus = data.loginStatus;
    digitalData.userInfo.userType = data.userType;
    digitalData.userInfo.userID = data.userId ? data.userId : '';
    console.log('onLoadTrack=======>', digitalData);
    if (localStorage.getItem('hitLoginSuccess')) {
      // debugger;
      localStorage.removeItem('hitLoginSuccess');
      trackLoginSuccessEvent();
      localStorage.getItem('hitLoginSuccess', false);
    }
    if (!_satellite) {
      console.log('analytics event is not working', _satellite);
    } else {
      _satellite?.track('yesConnect_PageLoad', digitalData);
    }
  } catch (e) {
    // debugger;
    window._satellite = {};
    console.log('_satellite not defined');
  }
};

export const subscribleClickEvent = (data) => {
  try {
    digitalData.eventInfo.eventName = data.eventName;
    digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
    digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
    digitalData.userInfo.userID = localStorage.getItem('userId');
    debugger;
    digitalData.productInfo.productName = data.productName;
    digitalData.productInfo.productType = data.productType;
    digitalData.productInfo.solutionName = data.solutionName;
    console.log('globalClickEvent=======>', digitalData);

    console.log('_satellite value', _satellite);
    if (_satellite && _satellite?.track) {
      _satellite?.track('yesConnect_event_click', digitalData);
    } else {
      console.log('analytics event is not working', _satellite);
    }
  } catch (e) {
    window._satellite = {};
    console.log('_satellite not defined');
  }
};

// product detail page & partner page detail
export const onLoadOfProductORPartnerDetail = (data) => {
  try {
    digitalData.productInfo.productName = data.productName;
    digitalData.productInfo.solutionName = data.solutionName;
    digitalData.productInfo.productType = data.productType;
    digitalData.PartnerName = data.partnerName;
    digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
    digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
    digitalData.userInfo.userID = localStorage.getItem('userId');
    console.log('onLoadOfProductORPartnerDetail=======>', digitalData);

    if (_satellite && _satellite?.track) {
      _satellite?.track('yesConnect_PageLoad', digitalData);
    } else {
      console.log('analytics event is not working', _satellite);
    }
  } catch (e) {
    window._satellite = {};
    console.log('_satellite not defined');
  }
};

export const onSubscribeBtnClick = (data) => {
  digitalData.eventInfo.eventName = 'subscribe';
  digitalData.productInfo.productName = data.productName;
  digitalData.productInfo.productType = data.productType;
  digitalData.productInfo.solutionName = data.solutionName;
  digitalData.PartnerName = data.partnerName;
  digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
  digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
  digitalData.userInfo.userID = localStorage.getItem('userId');
  console.log('onSubscribeBtnClick=======>', digitalData);

  console.log('_satellite value', _satellite);
  if (_satellite && _satellite?.track) {
    _satellite?.track('yesConnect_PageLoad', digitalData);
  } else {
    console.log('analytics event is not working', _satellite);
  }
};

export const globalClickEvent = (data) => {
  try {
    digitalData.eventInfo.eventName = data;
    digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
    digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
    digitalData.userInfo.userID = localStorage.getItem('userId');
    console.log('globalClickEvent=======>', digitalData);

    console.log('_satellite value', _satellite);
    if (_satellite && _satellite?.track) {
      _satellite?.track('yesConnect_event_click', digitalData);
    } else {
      console.log('analytics event is not working', _satellite);
    }
  } catch (e) {
    window._satellite = {};
    console.log('_satellite not defined');
  }
};

// export const subscribleClickEvent = (data) => {
//   try {
//     digitalData.eventInfo.eventName = data.eventName;
//     digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
//     digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
//     digitalData.userInfo.userID = localStorage.getItem('userId');
//     digitalData.productInfo.productName = data.productName;
//     digitalData.productInfo.productType = data.productType;
//     digitalData.productInfo.solutionName = data.solutionName;
//     console.log('globalClickEvent=======>', digitalData);

//     console.log('_satellite value', _satellite);
//     if (_satellite && _satellite?.track) {
//       _satellite?.track('yesConnect_event_click', digitalData);
//     } else {
//       console.log('analytics event is not working', _satellite);
//     }
//   } catch (e) {
//     window._satellite = {};
//     console.log('_satellite not defined');
//   }
// };

export const trackSearchEvent = (data) => {
  digitalData.eventInfo.eventName = 'Search Click';
  digitalData.searchInfo.searchKeyword = data;
  digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
  digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
  digitalData.userInfo.userID = localStorage.getItem('userId');
  console.log('trackSearchEvent=======>', digitalData);

  console.log('_satellite value', _satellite);
  if (_satellite && _satellite?.track) {
    _satellite?.track('yesConnect_search_click', digitalData);
  } else {
    console.log('analytics event is not working', _satellite);
  }
};

export const trackErrorEvent = (data) => {
  digitalData.eventInfo.eventName = data?.eventName;
  digitalData.errorInfo.errorMessage = data?.errorName;
  digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
  digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
  digitalData.userInfo.userID = localStorage.getItem('userId');
  console.log('trackRegisterAttemptEvent========>', digitalData);

  if (_satellite && _satellite?.track) {
    _satellite?.track('yesConnect_error', digitalData);
  } else {
    console.log('analytics event is not working', _satellite);
  }
};

export const trackRegisterAttemptEvent = () => {
  digitalData.eventInfo.eventName = 'Registration Attempt';
  digitalData.userInfo.accountType = localStorage.getItem('CA') === 'NO' ? 'NA' : 'current Account';
  console.log('trackRegisterAttemptEvent========>', digitalData);

  if (_satellite && _satellite?.track) {
    _satellite?.track('yesConnect_register_attempt', digitalData);
  } else {
    console.log('analytics event is not working', _satellite);
  }
};
export const trackRegisterSuccessEvent = () => {
  digitalData.eventInfo.eventName = 'Registration Success';
  digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
  digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
  digitalData.userInfo.userID = localStorage.getItem('userId');
  digitalData.userInfo.accountType = localStorage.getItem('CA') === 'NO' ? 'NA' : 'current Account';
  console.log('trackRegisterSuccessEvent========>', digitalData);

  if (_satellite && _satellite?.track) {
    _satellite?.track('yesConnect_register_sucess', digitalData);
  } else {
    console.log('analytics event is not working', _satellite);
  }
};

export const trackClickEvent = (trackEvent, eventName) => {
  digitalData.eventInfo.eventName = eventName;
  digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
  digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
  digitalData.userInfo.userID = localStorage.getItem('userId');
  console.log('trackClickEvent========>', digitalData);
  // digitalData.userInfo.accountType = localStorage.getItem('CA') === 'NO' ? 'NA' : 'current Account';
  if (_satellite && _satellite?.track) {
    _satellite?.track(trackEvent, digitalData);
  } else {
    console.log('analytics event is not working', _satellite);
  }
};

export const trackLoginAttemptEvent = () => {
  digitalData.eventInfo.eventName = 'Login Attempt';
  digitalData.userInfo.accountType = localStorage.getItem('userType') === 'pms' ? 'employee' : 'employee';
  console.log('trackLoginAttemptEvent========>', digitalData);
  if (_satellite && _satellite?.track) {
    _satellite?.track('yesConnect_login_attempt', digitalData);
  } else {
    console.log('analytics event is not working', _satellite);
  }
};
export const trackLoginSuccessEvent = () => {
  digitalData.eventInfo.eventName = 'Login Success';
  digitalData.userInfo.loginStatus = localStorage.getItem('userName') ? 'logged-in' : 'anonymous';
  digitalData.userInfo.userType = localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee';
  digitalData.userInfo.userID = localStorage.getItem('userId');
  digitalData.userInfo.accountType = localStorage.getItem('userType') === 'pms' ? 'employee' : 'employee';
  console.log('trackLoginSuccessEvent====>', digitalData);
  if (_satellite && _satellite?.track) {
    _satellite?.track('yesConnect_login_sucess', digitalData);
  } else {
    console.log('analytics event is not working', _satellite);
  }
};


import {SAVE_TADE_DATA,SAVE_TRADE_SUCCESS,SAVE_TRADE_FAIL,
  IS_REGISTRED,
  GET_CITY_SUCCESS, GET_CITY_FAILURE,GET_CITY,
  GET_TRADE_ACCOUNT_SUCCESS,GET_TRADE_ACCOUNT_FAILURE,
  SAVED_TRADE_OTP_SUCCESS,TRADE_SEND_OTP_LOADER,TRADE_VERIFY_OTP_LOADER,VERIFY_TRADE_OTP_SUCCESS, VERIFY_TRADE_OTP_FAIL
} from './constant';


export default function storeCases(state = {isRegistred: false,pcode: "91"}, action) {
    console.log(action);
    switch (action.type) {
//sava data trade
        case SAVE_TRADE_SUCCESS : 
        return {...state, trade_msg:'success', user_data: action.data}
      case SAVE_TRADE_FAIL : 
        return {...state, trade_msg:'fail', error_msg: action.data}
//product
        // case GET_PRODUCTS_SUCCESS:
        //   return { ...state, products: action.data, error: null };
        // case GET_PRODUCTS_FAILURE:
        //   return { ...state, products: [], error: action.error_message ? action.error_message : 'No Product available' };
        // case GET_BEYOND_DATA:
        //   console.log('under store================>', action.data);
        //   return { ...state, beyondlist: action.data, error: null };
// city data

          case GET_CITY_SUCCESS:
            return { ...state, city: action.data, error: null };
          case GET_CITY_FAILURE:
            return { ...state, city: [], error: action.error_message ? action.error_message : 'No Product available' };
            case GET_TRADE_ACCOUNT_SUCCESS:
              return { ...state, accountDetails: action.data, error: null };
            case GET_TRADE_ACCOUNT_FAILURE:
              return { ...state, error: action.error_message };
        default: return state;
//verify otp
        case VERIFY_TRADE_OTP_SUCCESS : 
        return {...state, verify_otp_state:'success', otp_message: action.data}
      case VERIFY_TRADE_OTP_FAIL : 
        return {...state, verify_otp_state:'fail', otp_message: action.data}
        case IS_REGISTRED : 
        return {...state,  isRegistred : action.data.result} 
 //otp loader       
        case SAVED_TRADE_OTP_SUCCESS: 
        return {...state, saved_otp_detail: 'success', otp_data: action.data} 
      case TRADE_SEND_OTP_LOADER:
        return {...state, senOtpLoader: action.payload}
      case TRADE_VERIFY_OTP_LOADER: 
        return {...state, verifyOtpLoader: action.payload} 
    }
    

}
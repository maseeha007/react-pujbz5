import { GET_SUBSCRIPTION_LIST,CANCEL_SUBSCRIPTION} from './constant';

export const getsubscriptionList = () => ( {
  type: GET_SUBSCRIPTION_LIST,
});

export const cancelsubscription = (id) =>({
    type:CANCEL_SUBSCRIPTION,
    payload:{id}
})
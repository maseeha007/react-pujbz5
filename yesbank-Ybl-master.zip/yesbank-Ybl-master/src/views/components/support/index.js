import React, { Component } from 'react';
import { Accordion, Card } from 'react-bootstrap';
import Header from '../../layout/header';
import Footer from '../../layout/footer';
import { withRouter } from 'react-router';
import { getAccountData } from '../account/actions';
import { connect } from 'react-redux';
import './style.scss';
import { onLoadTrack } from '../../../analytics';

class Support extends Component {
  constructor(props) {
    super(props);
    this.state = {
      key: '',
      accordData: [
        {
          id: '1',
          Question: 'Is YES Connect / API Banking relevant for my business',
          Answer:
            'If you are a business owner with a current account looking to optimize your cash management flows and optimize financial processes, YES Connect and its bouquet of API Banking solutions can definitely add value to your business.',
        },
        {
          id: '2',
          Question: 'What are the broad areas where YES Connect can be of help for my business',
          Answer:
            'YES Connect can help your business with gamut of API Banking solutions that can streamline your workflows around accounts payables, accounts receivables, accounting, payroll, inventory management, bulk payments etc.',
        },
        {
          id: '3',
          Question: 'How do I register myself on the YES Connect portal',
          Answer:
            'Just click on the ‘Register’ button on the right top corner of the site. Fill in your basic details, verify your mobile number and provide your Organization Customer Id (Cust Id) if you are an existing YES BANK customer. If you are not an existing customer, you can still register. Once registered, you may login to YES Connect and continue to explore our solutions.',
        },
        {
          id: '4',
          Question: 'How do I login to the YES Connect website',
          Answer:
            'You may log in in a few simple steps. Click on the login button, enter your registered mobile number, verify the received OTP and you can log in to view detailed technical specifications of our solutions.',
        },
        {
          id: '5',
          Question: 'What are the partner solutions displayed on the website',
          Answer: 'Partner solutions are the solutions offered by YES BANK’s partners and powered by the BANK’s APIs to cater to your business requirements. ',
        },
        {
          id: '6',
          Question: 'How do I become a partner with YES BANK',
          Answer:
            'There are two ways to become a partner on the YES Connect portal:' +
            '<ol> <li>While registering on the portal, express your interest in becoming a partner. Submit additional details like the name of the product you want to display along with a description of product.</li>' +
            '<li>You may also express your interest in becoming a partner on the Partners page of the YES Connect portal. Provide the required details about your product and our team will get in touch with you to help you get on boarded as a partner.</li></ol>',
        },
        {
          id: '7',
          Question: 'What if I don’t have an organization Cust Id? How may I register',
          Answer:
            'While registering, if you do not have an Organization Customer Id you may still go ahead and complete your registration. Our team will get in touch with you for opening a YES BANK Current Account.',
        },
        {
          id: '8',
          Question: 'How do I view the technical specifications of the product',
          Answer:
            'You will only be able to view the technical specifications of the product once you are logged in. After you have identified the product as per your criteria, navigate to the product details page of that product. Here you can go to the API definitions tab on the page and you can view the complete specifications of the API. You can view the operations and the definitions of the API in Curl and JAVA.',
        },
        {
          id: '9',
          Question: 'How do I subscribe to the product',
          Answer:
            'Once you have gone through the selected product and wish to subscribe the product, click on the ‘Subscribe’ button on the same product detail page. Fill in the required details on the subscription form, and place your request to subscribe to the chosen product. Our team will help in getting the product activated for you.',
        },
        {
          id: '10',
          Question: 'How do I get access to the production environment for the subscription',
          Answer:
            'Once you have an active current account, only then you can raise the subscription request for the production environment. Otherwise the option for subscription to UAT environment is always available in case the current account is not active.',
        },
        {
          id: '11',
          Question: 'How do I subscribe to the partner product',
          Answer:
            'Once you are on the partner product detail page, click on the Subscribe button, you will be navigated to the partner website where you can the view the complete details of the partner product. You can subscribe to this partner product from the partner’s website.',
        },
        {
          id: '12',
          Question: 'I am facing an error when subscribing for an API service. What can I do',
          Answer: 'In case you are facing any issues or error in navigating YES Connect, please write to DLYESCONNECT_SUPPORT@YESBANK.IN.',
        },
      ],
    };
  }

  componentDidMount() {
    this.props.getAccountData();
    const payload = {
      pageName: 'yes connect|faq',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
  }

  handleAccord = (e) => {
    this.setState({ ...this.state, key: e });
  };

  render() {
    return (
      <>
        <Header title="FAQ" />
        <section id="support">
          <div className="banner-container">
            <h2 className="banner-heading">FAQ </h2>
          </div>
          <div className="body">
            <div className="accord-container">
              <div className="email-section">
                <img src="/assets/img/email-icon.svg" alt="Email Image" />
                <span>
                  For further queries contact us on <a href="mailto:DLYESCONNECT_SUPPORT@YESBANK.IN?Subject=subject here">DLYESCONNECT_SUPPORT@YESBANK.IN</a>
                </span>
              </div>
            </div>
            {this.state.accordData.map((data, index) => (
              <Accordion
                className="accord-container"
                // defaultActiveKey="1"
                onSelect={(e) => this.handleAccord(e)}
              >
                <Card>
                  <Accordion.Toggle className={this.state.key == index + 1 ? 'accord-header-after' : 'accord-header'} as={Card.Header} eventKey={index + 1}>
                    <span className="accord-title">
                      Q.{index + 1} {data.Question} ?
                    </span>{' '}
                    {this.state.key == index + 1 ? (
                      <img className="header-icon" src="assets/icons/down-arrow.svg" />
                    ) : (
                      <img className="header-icon" src="assets/icons/right-arrow.svg" />
                    )}
                  </Accordion.Toggle>
                  <Accordion.Collapse eventKey={index + 1}>
                    <Card.Body className={this.state.key == index + 1 ? 'answer-container-after' : 'answer-container'}>
                      <span className="accord-text-spn">A.</span>
                      <div className="accord-text" dangerouslySetInnerHTML={{ __html: data.Answer }}>
                        {/* {} */}
                      </div>
                    </Card.Body>
                  </Accordion.Collapse>
                </Card>
              </Accordion>
            ))}
          </div>
        </section>
        <Footer />
      </>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    ...state,
  };
};

const mapDispatchToProps = (dispatch) => ({
  getAccountData: () => dispatch(getAccountData()),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Support));

// export default Support;

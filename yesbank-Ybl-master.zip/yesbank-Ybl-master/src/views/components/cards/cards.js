import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Tooltip, OverlayTrigger } from 'react-bootstrap';
import './style.scss';
import { connect } from 'react-redux';
import { globalClickEvent } from '../../../analytics';
function Cards(props) {
  const renderTooltip = (props, feature) => (
    console.log('checking feature', props),
    (
      <Tooltip id="button-tooltip" {...props}>
        <div className="feature-heading-container">
          <h1 className="feature-heading">Features</h1>
        </div>
        {props.map((feature, index) => (
          <ul className="listing">
            {index < 4 && (
              <li className="tooltip-heading">
                <span className="tooltip-heading_icon"></span>
                <p>{feature.featureName}</p>
              </li>
            )}
          </ul>
        ))}
      </Tooltip>
    )
  );
  const movetoNextPage = (name, isyblProduct, solution, pid) => {
    const url =
      isyblProduct === 'true'
        ? `/product?id=${pid}&name=${name}&solutionName=${solution}`
        : `/partnerdetails?id=${pid}&name=${name}&solname=${solution.replace('&', '~')}`;
    globalClickEvent(`link clicked on Explore page ${name}`);
    window.location.href = url;
  };
  return (
    <section id="cards">
      <div className="card-container">
        <Row noGutters={true} className="fixed-width-section">
          {props.data.map((product, index) => (
            <div className="cols">
              <OverlayTrigger
                isOpen={true}
                placement={index % 3 === 0 ? 'right' : 'left'}
                delay={{ show: 200, hide: 20 }}
                overlay={renderTooltip(product.feature)}
              >
                <Link
                  className="slink"
                  // to={
                  //   product.isYblProduct === 'true'
                  //     ? `/product?id=${product.productId}&name=${product.productName}&solutionName=${props.solution}`
                  //     : '/partnerdetails?id=' + product.productId + '&name=' + product.productName + '&solname=' + props.solution.replace('&', '~')
                  // }
                  onClick={movetoNextPage.bind(this, `${product.productName}`, `${product.isYblProduct}`, props.solution, product.productId)}
                >
                  <Card className="solutionCard">
                    <Card.Body className="no-pad">
                      <img
                        className="oval"
                        src={
                          product.isYblProduct === 'true'
                            ? '/assets/explore/' + String(product.productName).toLowerCase().replace(/\s/g, '-') + '.svg'
                            : '/assets/explore/zoho-books.svg'
                        }
                        alt=""
                      />
                      <Card.Title className="scard-title">{product.productName}</Card.Title>
                      <Card.Text className="scard-text">{product.description}</Card.Text>
                      {product.isYblProduct === 'true' ? (
                        <span>
                          {/* <img
                            className="logo-img"
                            src="/assets/img/logo.svg"
                            alt=""
                          /> */}
                        </span>
                      ) : (
                        <span>
                          <img className="logo-img" src={'/assets/img/' + String(product.productName).toLowerCase().replace(/\s/g, '-') + '-logo.svg'} alt="" />
                        </span>
                      )}
                    </Card.Body>
                  </Card>
                </Link>
              </OverlayTrigger>
            </div>
          ))}
        </Row>
      </div>
    </section>
  );
}
const mapStateToProps = (state) => ({
  products: state.solutionsReducer.products,
});
const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(Cards);

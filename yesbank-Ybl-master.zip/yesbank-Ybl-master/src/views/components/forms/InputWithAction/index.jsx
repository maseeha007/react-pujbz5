import React, { useState, useRef, useEffect } from "react";
import { Form, FormControl, InputGroup, Spinner } from 'react-bootstrap';
import classnames from 'classnames';
import './style.scss';




const InputWithAction = (props, ref) => {
    const inputEl = useRef();

    const [state, setState] = useState({ edited: false })

    const innerFocus = () => {
        setState({ ...state, 'edited': true, 'hasText': props.defaultValue })
    }

    function toTime(time) {
        var sec_num = parseInt(time, 10);
        var hours = Math.floor(sec_num / 3600);
        var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
        var seconds = sec_num - (hours * 3600) - (minutes * 60);

        if (hours < 10) { hours = "0" + hours; }
        if (minutes < 10) { minutes = "0" + minutes; }
        if (seconds < 10) { seconds = "0" + seconds; }
        return minutes + ':' + seconds;
    }

    const innerBlur = () => {
        const value = inputEl.current.value
        if (value) {
            setState({ ...state, 'hasText': true, 'edited': false })
        } else {
            setState({ ...state, 'hasText': false, 'edited': false })
        }
    }


    const innerClick = () => {
        if (!props.disabled) {
            inputEl.current.focus();
            setState({ ...state, 'edited': true })
        }
    }

    useEffect(() => {
        const value = inputEl.current.value
        if (value) {
            setState({ ...state, 'hasText': true, 'edited': false })
        } else {
            setState({ ...state, 'hasText': false, 'edited': false })
        }
    }, [props])

    console.log(props.showLoader, 'show Loader')

    return (
        <div className={classnames({ "ybl-ph": true, 'active': state.edited, 'disabled': props.disabled })}  >
            <InputGroup>
                <div className="relative-div flex">
                    <input type="text" className="form-control" value={props.disabled ? (props.defaultValue ? props.defaultValue : '') : (props.defaultValue ? props.defaultValue : undefined)} ref={ref} disabled={props.disabled} ref={inputEl} onKeyDown={(event) => { props.maskKey && props.maskKey(event) }} onChange={props.onChange} onFocus={() => { innerFocus(); }} onBlur={() => { innerBlur(); }} {...props} maxLength="35" />
                    <Form.Label ref={el => {
                        el &&
                            el.addEventListener("selectstart", (e) => {
                                e.preventDefault()
                            });
                    }}
                        onClick={() => { innerClick() }} className={classnames({ 'has-text': props.defaultValue || state['hasText'] })}>{props.label ? props.label : ''}{props.required ? <span className="required">*</span> : null} </Form.Label>
                </div>
            </InputGroup>
            <div className={classnames({ 'flex': true, 'flex-end': !props.error, 'phone-section': true })}>
                {props.error && <div className="error">{props.error}</div>}
                {/* {props.hideSendButton ? null : <span onClick={props.otpClick} className={classnames({ "btn-link": true, "no-timer": !props.timeStr, "otp-disabled": (props.otpDisabled || !props.disableSendOtpLink) })}>
                    {props.otpText ? props.otpText : 'Send OTP'} {props.timeStr ? <span>({toTime(props.timeStr)})</span> : null}
                    {props.showLoader && <Spinner animation="border" />}
                </span>} */}
                {/* {props.showLoader && <Spinner animation="border" /> }     */}
                <span onClick={props.otpClick} className={classnames({ "btn-link": true })}>Check ADID</span>
                {props.showLoader && <Spinner animation="border" />}
                {/* Loader concept is left  */}
            </div>
        </div>
    );
}

export default InputWithAction;

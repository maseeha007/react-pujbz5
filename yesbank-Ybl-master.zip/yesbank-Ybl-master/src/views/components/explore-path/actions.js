import { GET_SOLUTIONS_PATH, GET_TAGS_DATA, UPDATE_EXPLORE_PATH_LIST } from './constant';

export const getSolutions = (payload = {}) => ({
  type: GET_SOLUTIONS_PATH,
  payload,
});

export const getTagsData = (tags, boolean) => ({
  type: GET_TAGS_DATA,
  payload: { tags, boolean },
});

export const updateExploreList = (tags) => ({
  type: UPDATE_EXPLORE_PATH_LIST,
  payload: { tags, boolean: '' },
});

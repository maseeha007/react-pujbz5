import { all, call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { fetchSolutions, fetchTagsSolutions } from './api';
import { GET_PRODUCTS_SUCCESS, GET_SOLUTIONS_PATH, GET_PRODUCTS_FAILURE, GET_TAGS_DATA, UPDATE_EXPLORE_PATH_LIST } from './constant';

export function* GetSolutionAsync(payload = {}) {
  try {
    const data = yield call(fetchSolutions.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_PRODUCTS_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_PRODUCTS_FAILURE,
        error_message: data.data.message ? data.data.message : 'No matching product found.',
      });
    }
  } catch (error) {
    yield put({
      type: GET_PRODUCTS_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
  }
}

export function* GetTagsDataAsync({ payload }) {
  try {
    const data = yield call(fetchTagsSolutions.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_PRODUCTS_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_PRODUCTS_FAILURE,
        error_message: 'No matching product found.',
      });
    }
  } catch (error) {
    yield put({
      type: GET_PRODUCTS_FAILURE,
      error_message: 'No matching products found.',
    });
  }
}

export function* updateExplorePageAsync({ payload }) {
  try {
    const data = yield call(fetchTagsSolutions.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_PRODUCTS_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_PRODUCTS_FAILURE,
        error_message: 'No matching product found.',
      });
    }
  } catch (error) {
    yield put({
      type: GET_PRODUCTS_FAILURE,
      error_message: 'No matching products found.',
    });
  }
}
//UPDATE_EXPLORE_PATH_LIST

export default function* watchAll() {
  yield all([
    takeLatest(GET_SOLUTIONS_PATH, GetSolutionAsync),
    takeLatest(GET_TAGS_DATA, GetTagsDataAsync),
    takeLatest(UPDATE_EXPLORE_PATH_LIST, updateExplorePageAsync),
  ]);
}

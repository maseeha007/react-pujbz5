import {
  GET_ACCOUNT_DETAILS,
  UPDATE_CUST_ID_MYACCOUNT,
  CLEAR_MYACCOUNT_DATA,
  MYACCOUNT_SEND_OTP_LOADER,
  MYACCOUNT_VERIFY_OTP_LOADER,
  MYACCOUNT_CUST_API_CALL,
  MYACCOUNT_SEND_OTP_API_CALL,
  MYACCOUNT_VERIFY_OTP_API_CALL,
  MYACCOUNT_CUSTID_LOADER,
  MYACCOUNT_REFRESH_CAPTCHA,
  MYACCOUNT_REMOVE_CUSTID,
  MYACCOUNT_CUSTIDS,
  MYACCOUNT_DEFAULT_CUSTID,
} from './constant';

export const getAccountData = () => ({
  type: GET_ACCOUNT_DETAILS,
});

export const updateCustId = (custId) => ({
  type: UPDATE_CUST_ID_MYACCOUNT,
  custId: custId,
});

export const clearData = () => ({
  type: CLEAR_MYACCOUNT_DATA,
});

export const sendOtpLoaderAction = (flag) => ({
  type: MYACCOUNT_SEND_OTP_LOADER,
  payload: flag,
});

export const sendOtpCAUser = (custId) => ({
  type: MYACCOUNT_SEND_OTP_API_CALL,
  payload: custId,
});

export const verifyOTPLoader = (flag) => ({
  type: MYACCOUNT_VERIFY_OTP_LOADER,
  payload: flag,
});

export const verifyOtpAction = (otp, captcha) => ({
  type: MYACCOUNT_VERIFY_OTP_API_CALL,
  payload: { otp, captcha },
});

export const setServerError = (err) => ({
  type: 'CUSTID_UPDATE_ERROR',
  payload: err,
});

export const custICheckAction = (custId) => ({
  type: MYACCOUNT_CUST_API_CALL,
  payload: custId,
});
export const makeDefaultCustId = (custId) => ({
  type: MYACCOUNT_DEFAULT_CUSTID,
  payload: custId,
});
export const custIDLoaderAction = (flag) => ({
  type: MYACCOUNT_CUSTID_LOADER,
  payload: flag,
});

export const refreshCaptcha = () => ({
  type: MYACCOUNT_REFRESH_CAPTCHA,
});
export const setCustIds = (list) => ({
  type: MYACCOUNT_CUSTIDS,
  payload: list,
});

export const removeCustId = (custId) => ({
  type: MYACCOUNT_REMOVE_CUSTID,
  payload: custId,
});

import { all, call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { fetchAccountDetails, updateCustIdAsync, refreshToken, validCAUserOnRegistration, removeCustId, updateDefaultCustId } from './api';
import {
  GET_ACCOUNT_DETAILS,
  GET_ACCOUNT_SUCCESS,
  GET_ACCOUNT_FAILURE,
  UPDATE_MY_ACCOUNT_LOADER,
  CUSTID_UPDATE_SUCCESS,
  CUSTID_UPDATE_ERROR,
  UPDATE_CUST_ID_MYACCOUNT,
  MYACCOUNT_SEND_OTP_STATUS,
  MYACCOUNT_SEND_OTP_SUCCESS,
  MYACCOUNT_VERIFY_OTP_SUCCESS,
  MYACCOUNT_SEND_OTP_LOADER,
  MYACCOUNT_VERIFY_OTP_STATUS,
  SET_MYACCOUNT_DATA,
  MYACCOUNT_CUST_API_CALL,
  MYACCOUNT_SEND_OTP_API_CALL,
  MYACCOUNT_VERIFY_OTP_API_CALL,
  MYACCOUNT_CUSTID_LOADER,
  MYACCOUNT_VERIFY_CUST_SUCCESS,
  MYACCOUNT_VERIFY_OTP_LOADER,
  MYACCOUNT_CAPTCHA,
  MYACCOUNT_REFRESH_CAPTCHA,
  MYACCOUNT_REMOVE_CUSTID,
  MYACCOUNT_CUSTIDS,
  MYACCOUNT_DEFAULT_CUSTID,
} from './constant';
import { verifyYBLOTPAPI, sendYBLOTP, verifyOTPMyAccountAPI } from '../../../service/otpAPI';

export function* removeCustIdMyAccount({ payload }) {
  try {
    const res = yield removeCustId(payload);
    if (res.data.statusType == 'SUCCESS') {
      //TODO
      // yield put({ type: CUSTID_UPDATE_SUCCESS });
      yield put({ type: MYACCOUNT_CUSTIDS, data: JSON.parse(res.data) });
    } else {
      yield put({
        type: GET_ACCOUNT_FAILURE,
        error_message: res.data.statusMessage,
      });
    }
  } catch (error) {
    yield put({
      type: GET_ACCOUNT_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if (('Unauthorized' === error?.response?.data?.error || error?.response?.status === 401) && token) {
      window.location.href = '/';

      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    } else {
      yield put({
        type: GET_ACCOUNT_FAILURE,
        error_message: 'Some Network Problem Occured',
      });
    }
  }
}
export function* GetAccountDataAsync() {
  try {
    const data = yield call(fetchAccountDetails);
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_ACCOUNT_SUCCESS, data: data.data.response });
      yield put({ type: MYACCOUNT_CUSTIDS, data: JSON.parse(data.data.response.custId) });
    } else {
      yield put({
        type: GET_ACCOUNT_FAILURE,
        error_message: data.data.statusMessage,
      });
    }
  } catch (error) {
    yield put({
      type: GET_ACCOUNT_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if (('Unauthorized' === error?.response?.data?.error || error.response.status === 401) && token) {
      window.location.href = '/';
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    }
  }
}

export function* UpdateCustIdAsync(custId) {
  try {
    debugger;
    const res = yield updateCustIdAsync(custId);
    if (res.data.statusType == 'SUCCESS') {
      yield put({ type: CUSTID_UPDATE_SUCCESS });
      yield put({ type: SET_MYACCOUNT_DATA, data: res.data });
    } else {
      yield put({ type: CUSTID_UPDATE_ERROR });
    }
    yield put({
      type: UPDATE_MY_ACCOUNT_LOADER,
      data: false,
    });
  } catch (error) {
    yield put({
      type: GET_ACCOUNT_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if (('Unauthorized' === error?.response?.data?.error || error?.response?.status === 401) && token) {
      window.location.href = '/';
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    } else {
      yield put({ type: CUSTID_UPDATE_ERROR });
    }
    yield put({
      type: UPDATE_MY_ACCOUNT_LOADER,
      data: false,
    });
  }
}

export function* makeDefaultCustId(custId) {
  try {
    debugger;
    const res = yield updateCustIdAsync(custId);
    if (res.data.statusType == 'SUCCESS') {
      yield put({ type: CUSTID_UPDATE_SUCCESS });
      yield put({ type: SET_MYACCOUNT_DATA, data: res.data });
    } else {
      yield put({ type: CUSTID_UPDATE_ERROR });
    }
    yield put({
      type: UPDATE_MY_ACCOUNT_LOADER,
      data: false,
    });
  } catch (error) {
    yield put({
      type: GET_ACCOUNT_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if (('Unauthorized' === error?.response?.data?.error || error?.response?.status === 401) && token) {
      window.location.href = '/';
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    } else {
      yield put({ type: CUSTID_UPDATE_ERROR });
    }
    yield put({
      type: UPDATE_MY_ACCOUNT_LOADER,
      data: false,
    });
  }
}

export function* sendOtpForMyAccount({ payload }) {
  debugger;
  const sendotppayload = {
    isCaUser: true,
    custId: payload,
  };

  try {
    debugger;
    const data = yield sendYBLOTP(sendotppayload)
      .then((res) => {
        if (res.headers['sessionid']) {
          localStorage.setItem('sessionId', res.headers['sessionid']);
        }
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });

    if (data.statusType === 'FAIL') {
      yield put({ type: CUSTID_UPDATE_ERROR, data: data.statusMessage });
    }
    if (data.statusType === 'REQUEST IS NOT APPROPRIATE') {
      yield put({ type: CUSTID_UPDATE_ERROR, data: data.response });
    }

    if (data.statusType === 'SUCCESS') {
      const res = { ...data };
      yield put({ type: MYACCOUNT_SEND_OTP_STATUS, payload: true });
      yield put({ type: MYACCOUNT_SEND_OTP_SUCCESS, data: res });
      // yield put({ type: SET_MYACCOUNT_DATA, data: { result: data.statusMessage } });
    }
  } catch (err) {
    console.log(err);
    yield put({ type: CUSTID_UPDATE_ERROR, data: 'Unable to connect to YES BANK API' });
  }
  yield put({ type: MYACCOUNT_SEND_OTP_LOADER, payload: false });
}

export function* verifyOtpAsync({ payload }) {
  debugger;
  try {
    // const state = yield select();
    const reqPayload = {
      otpValue: payload.otp,
      isCaUser: true,
      isMyaccount: true,
      captcha: payload.captcha,
    };

    const data = yield verifyOTPMyAccountAPI(reqPayload)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });
    if (data.statusType === 'SUCCESS') {
      if (data.response.verifyOTPResponse.isValid == 'true') {
        yield put({ type: MYACCOUNT_VERIFY_OTP_SUCCESS, data: 'Otp Verified' });
        yield put({ type: MYACCOUNT_VERIFY_OTP_LOADER, payload: false });
        yield put({ type: MYACCOUNT_VERIFY_OTP_STATUS, data: 'success' });
        yield put({ type: SET_MYACCOUNT_DATA, data: data.response });
        localStorage.setItem('CaVerifed', 'YES');
      }
    }
    if (data.statusType === 'FAIL') {
      yield put({ type: MYACCOUNT_VERIFY_OTP_STATUS, data: 'fail' });
      yield put({ type: CUSTID_UPDATE_ERROR, data: data.statusMessage });
      yield put({ type: MYACCOUNT_VERIFY_OTP_LOADER, payload: false });
    }
  } catch (e) {
    yield put({ type: MYACCOUNT_VERIFY_OTP_STATUS, data: 'fail' });
    yield put({ type: CUSTID_UPDATE_ERROR, data: 'Invalid Otp' });
    yield put({ type: MYACCOUNT_VERIFY_OTP_LOADER, payload: false });
  }
}

export function* fetchCustStatusAsync({ payload }) {
  debugger;
  try {
    const custId = payload;
    const res = yield validCAUserOnRegistration(custId);
    debugger;
    localStorage.setItem('sessionId', res?.headers['sessionid']);
    // yield put({ type: SET_MYACCOUNT_DATA, data: res?.data });
    // for testing

    if (res?.data?.response?.responseCode == '0') {
      yield put({ type: MYACCOUNT_CUSTID_LOADER, payload: false });
      yield put({ type: MYACCOUNT_VERIFY_CUST_SUCCESS, data: { response: 'verfied' } });
      const response = res?.data?.response;
      response.custId = custId;
      yield put({ type: MYACCOUNT_CAPTCHA, payload: res?.data?.response?.captchaResponse?.captcha });
      yield put({ type: SET_MYACCOUNT_DATA, data: response });
    } else {
      yield put({ type: MYACCOUNT_CUSTID_LOADER, payload: false });
      yield put({ type: CUSTID_UPDATE_ERROR, data: 'Not Verifed' });
      yield put({ type: MYACCOUNT_VERIFY_CUST_SUCCESS, data: { response: 'notverfied' } });
    }
  } catch (error) {
    yield put({ type: CUSTID_UPDATE_ERROR, data: 'Some Network Error Occurred' });
    yield put({ type: SUB_VERIFY_CUSTID_LOADER, payload: false });
  }
}

export function* refreshCaptchaAPI({ payload }) {
  // debugger;
  const res = yield refreshToken()
    .then((res) => {
      return res;
    })
    .catch((e) => {
      const errorObj = e.response ? e.response.data : e.message;
      return errorObj;
    });
  const { data } = res;
  if (data.statusMessage === 'SUCCESS') {
    yield put({ type: MYACCOUNT_CAPTCHA, payload: data.response.captcha });
  } else {
    yield put({ type: MYACCOUNT_CAPTCHA, payload: '' });
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(GET_ACCOUNT_DETAILS, GetAccountDataAsync),
    takeLatest(UPDATE_CUST_ID_MYACCOUNT, UpdateCustIdAsync),
    takeLatest(MYACCOUNT_CUST_API_CALL, fetchCustStatusAsync),
    takeLatest(MYACCOUNT_SEND_OTP_API_CALL, sendOtpForMyAccount),
    takeLatest(MYACCOUNT_VERIFY_OTP_API_CALL, verifyOtpAsync),
    takeLatest(MYACCOUNT_REFRESH_CAPTCHA, refreshCaptchaAPI),
    takeLatest(MYACCOUNT_REMOVE_CUSTID, removeCustIdMyAccount),
    takeLatest(MYACCOUNT_DEFAULT_CUSTID, makeDefaultCustId),
  ]);
}

import axios from 'axios';
import { APIURL } from '../../../env';

const fetchAccountDetails = () => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
    },
  };
  let response = axios.get(`${window.yblDomain}/apihub/user?isCaAccountStatusRequired=true&role=${localStorage.getItem('role')}`, config);
  return response;
};

const updateCustIdAsync = (req) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
    },
  };
  let payload = {
    custId: req.custId,
    isSetPrimary: false,
  };
  let response = axios.post(`${window.yblDomain}/apihub/user/updateCustId`, payload, config);
  return response;
};

const updateDefaultCustId = (req) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
    },
  };
  //debugger;
  let payload = {
    custId: req.custId,
    isSetPrimary: true,
  };
  let response = axios.post(`${window.yblDomain}/apihub/user/updateCustId`, payload, config);
  return response;
};

const refreshToken = () => {
  const url = `${window.yblDomain}/ybl/refreshCaptcha`;
  let header = {};
  if (localStorage.getItem('sessionId')) {
    header = { headers: { sessionid: localStorage.getItem('sessionId') } };
  }
  return axios.get(url, header);
};

const validCAUserOnRegistration = (id, contactDetails) => {
  const url = `${window.yblDomain}/ybl/caVerify`;
  const payload = {
    custId: id,
    isMyaccount: true,
  };
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
    },
  };
  return axios.post(url, payload, config);
};
const removeCustId = (custId) => {
  const url = `${window.yblDomain}/apihub/user/removeCustId`;
  let header = {};
  if (localStorage.getItem('sessionId')) {
    header = { headers: { 'Content-Type': 'application/json', Authorization: 'Bearer' + ' ' + localStorage.getItem('token') } };
  }
  let payload = {
    custId,
  };
  return axios.post(url, payload, header);
};

export { fetchAccountDetails, updateCustIdAsync, validCAUserOnRegistration, refreshToken, removeCustId, updateDefaultCustId };

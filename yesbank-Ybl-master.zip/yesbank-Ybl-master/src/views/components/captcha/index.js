import React from 'react';
import './style.scss';
const Captcha = ({ base64Data, clickEvent }) => {
  return (
    <div>
      <img className="img" src={`data:image/jpeg;base64,${base64Data}`} />
      <span className="refresh-link" onClick={clickEvent}>
        <img src="/assets/icons/refresh.svg" alt="refresh" />
      </span>
    </div>
  );
};

export default Captcha;

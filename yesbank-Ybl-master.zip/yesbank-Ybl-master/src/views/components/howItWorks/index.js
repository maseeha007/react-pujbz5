import React, { Component } from 'react';
import { Tabs, Tab } from 'react-bootstrap';
import Header from '../../layout/header';
import Footer from '../../layout/footer';
import ForUser from '../forUsers/index';
import ForPartners from '../forPartners/index';
import './style.scss';
import { withRouter } from 'react-router';
import { getAccountData } from '../account/actions';
import { connect } from 'react-redux';
import { onLoadTrack } from '../../../analytics';

class Index extends Component {
  componentDidMount() {
    this.props.getAccountData();
    const payload = {
      pageName: 'yes connect|getstarted',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
  }
  render() {
    return (
      <>
        <Header title="Get Started" />
        <section id="howitworks">
          <h1 className="main-heading">Get Started</h1>
          <div className="tab-container">
            <div className="tab-data">
              <Tabs defaultActiveKey="users" id="uncontrolled-tab-example">
                <Tab eventKey="users" title="For Users">
                  <ForUser />
                </Tab>
                <Tab eventKey="partners" title="For Partners">
                  <ForPartners />
                </Tab>
              </Tabs>
            </div>
          </div>
        </section>
        <Footer />
      </>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    ...state,
  };
};

const mapDispatchToProps = (dispatch) => ({
  getAccountData: () => dispatch(getAccountData()),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));

import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Tabs, Tab, Accordion, Card, Button, Modal, Toast, Spinner, Alert, Form } from 'react-bootstrap';
import Radio from '../../components/forms/radio';

// import Input from '../../components/forms/input';
import { scroller } from 'react-scroll';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';
import PartnerDetailbanner from '../partnerDetailBanner/index';
import { updatePartner } from '../partnerProducts/action';
import { getAccountData } from '../account/actions';
import {
  getOverview,
  getFeatures,
  checkSubscribe,
  sentEmailForNonCA,
  verifyCa,
  sendOtpCAUser,
  verifyOtp,
  sendOtpLoaderAction,
  setError,
  subscribeAction,
} from './action';
import { loginModalStatus } from '../../layout/header/action';
import Input from '../forms/input';
import Login from '../login/index';
import { connect } from 'react-redux';
import { onLoadOfProductORPartnerDetail, onSubscribeBtnClick, globalClickEvent } from '../../../analytics';
import Offers from '../offers';
import PhoneNumber from '../../components/forms/phoneNumber';
import Otp from '../../components/forms/otp';
import './style.scss';

class partnerDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openPopup: false,
      details: {},
      error: {},
      showlogin: false,
      id: '',
      name: '',
      solution: '',
      key: '',
      openToast: false,
      showSubscribe: false,
      showVideo: false,
      taosterShown: false,
      showfailOpen: false,
      showSubscribe_error: false,
      subscribedDone: false,
      statusUpdated: false,
      checkUser: '',
      introduction: null,
      features: null,
      isCustIdVisible: true,
      otpVerified: false,
      otpDisabled: true,
      otpTime: 0,
    };
    this.timer = null;
  }
  parseQuery(queryString) {
    var query = {};
    var pairs = (queryString[0] === '?' ? queryString.substr(1) : queryString).split('&');
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i].split('=');
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || '');
    }
    return query;
  }

  componentDidUpdate(prevProp) {
    if (this.props.updateLogin == 1 && this.state.partnerUpdated !== true) {
      setTimeout(() => {
        this.setState({
          ...this.state,
          partnerUpdated: true,
          openPopup: false,
        });
      }, 2000);
    }

    if (this.props.issubscribed.statusCode == 200 && !this.state.taosterShown) {
      if (this.props.issubscribed.statusType == 'Not Updated') {
        this.setState({ ...this.state, openToast: true, taosterShown: true });
      } else if (this.props.issubscribed.statusType == 'SUCCESS') {
        this.setState({ ...this.state, showSubscribe: true, taosterShown: true, otpDisabled: false });
      } else if (this.props.issubscribed.statusCode == 500) {
        this.setState({ ...this.state, showSubscribe_error: true });
      }
    }
    if (prevProp.otpStatus !== this.props.otpStatus && this.props.otpStatus) {
      this.setState({ ...this.state, otpTime: 0, otpDisabled: true });
      clearInterval(this.timer);
    }
    // if (prevProp.introduction !== this.props.introduction) {
    //   this.setState({ introduction: this.props.introduction && this.props.introduction.map((a) => a.replace(/(<([^>]+)>)/gi, '')) });
    // }
    if (prevProp.features !== this.props.features) {
      const numsPerGroup = Math.ceil(this.props?.features.length / 3);
      const result = new Array(3).fill('').map((_, i) => this.props.features.slice(i * numsPerGroup, (i + 1) * numsPerGroup));
      this.setState({
        features: result,
      });
    }
    if (prevProp.isOtpSent !== this.props.isOtpSent && this.props.isOtpSent) {
      this.setState({ ...this.state, otpSent: true, otpDisabled: false, startTimer: true });
      this.timer = setInterval(() => {
        this.setState({ ...this.state, otpTime: this.state.otpTime ? this.state.otpTime - 1 : 60 });
      }, 1000);
      setTimeout(() => {
        if (this.timer !== null) {
          this.setState({ ...this.state, otpDisabled: false, otpTime: 0, startTimer: false, OtpText: 'Resend OTP' });
        }
        clearInterval(this.timer);
      }, 60000);
    }
  }
  componentDidMount() {
    this.props.getAccountData();
    var qs = this.parseQuery(window.location.search);
    if (qs.id && qs.id !== undefined) {
      // debugger;
      this.props.getFeatures(qs.id);
      this.props.getOverview(qs.id);
      // this.props.getFeatures(qs.id);
      this.setState({ ...this.state, id: qs.id, name: qs.name, solution: qs.solname });
      // debugger;
      const payload = {
        productName: null,
        solutionName: qs?.solname.replace('~', '&'),
        productType: 'partner product',
        partnerName: qs.name,
      };
      onLoadOfProductORPartnerDetail(payload);
      debugger;
      this.props.subscribeAction(qs.id, localStorage.getItem('token'));
    }
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
  saveValue(name, e) {
    let value = e.target.value;
    if (name === 'solname' || name === 'desc') {
      value = e.target.value.replace(/[^a-z0-9 ]/gi, '');
    }
    this.setState({
      ...this.state,
      details: { ...this.state.details, [name]: value },
    });
  }

  handleLogin() {
    let flag = false;
    let errObj = {};
    let dataObj = {};

    if (!this.state.details.solname) {
      errObj['solname'] = 'Please Enter Product/Solution';
      document.getElementById('solname').focus();
      flag = true;
    } else {
      dataObj['solname'] = this.state.details.solname;
    }

    if (!this.state.details.desc) {
      errObj['desc'] = 'Please Enter description';
      if (!flag) {
        document.getElementById('desc').focus();
      }

      flag = true;
    } else {
      dataObj['desc'] = this.state.details.desc;
    }
    if (flag) {
      this.setState({ ...this.state, error: { ...errObj } });
      return;
    } else {
      let userObj = {
        custId: this.props.accountValues.custId,
        firstName: this.props.accountValues.firstName,
        lastName: this.props.accountValues.lastName,
        emailId: this.props.accountValues.emailId,
        isEnabled: this.props.accountValues.isEnabled,
        mobile: this.props.accountValues.mobile,
        organisation: this.props.accountValues.organisation,
        partnerOptIn: this.props.accountValues.partnerOptIn,
        solutionName: dataObj.solname,
        productDescription: dataObj.desc,
        leadgenStatus: this.props.accountValues.leadgenStatus,
      };
      this.props.updatePartner(userObj);
      setTimeout(() => {
        this.setState({ ...this.state, openPopup: false });
        window.location.reload();
      }, 5000);
    }
  }

  handleClose = () => {
    this.setState({ ...this.state, error: {}, openPopup: false });
    // window.location.reload();
  };
  handleOpen() {
    if (!localStorage.token) {
      globalClickEvent(`button clicked login`);
      this.props.openModal();
    } else {
      globalClickEvent(`button clicked Add Partner detail`);
      this.setState({ ...this.state, openPopup: true });
    }
  }
  handleSubscrption() {
    let isError = false;
    this.setState({ ...this.state, isCustIdError: false, custErrorMsg: '' });
    // debugger;
    if (!localStorage.token) {
      globalClickEvent(`button clicked login`);
      this.props.openModal();
    } else {
      let payload = {
        name: this.state.name,
        productId: this.props.OverviewValues.productId,
      };
      if (this.state.isCustIdVisible) {
        if (this.props?.accountValues?.custId || this.state?.custId || this.state.caNumber) {
          // isError = true;
          payload.custId = this.props?.accountValues?.custId ? this.props?.accountValues?.custId : this.state.custId;
        }
        if (this.state.caNumber) {
          payload.custId = this.state.caNumber;
        }
        if (!payload.custId) {
          isError = true;
          this.setState({ ...this.state, isCustIdError: true, custErrorMsg: 'Please Enter Valid Cust Id' });
        }
        if (payload.custId && !this.props?.verify_user_state) {
          isError = true;
          this.setState({ ...this.state, isCustIdError: true, custErrorMsg: 'Please Verify Cust Id' });
        }
        if (this.props.otpStatus != 'success') {
          isError = true;
          this.props.setError('Please varify cust Id with OTP');
        }
      }
      // debugger;
      if (!isError) {
        debugger;
        this.props.setError(undefined);
        this.props.checkSubscribe(payload);
        window.open(this.props.OverviewValues.redirectURL);
        window.blur();

        if (Object.keys(this.props?.accountValues).length) {
          const payload = {
            firstName: this.props?.accountValues?.firstName,
            lastName: this.props?.accountValues?.lastName,
            organisation: this.props?.accountValues?.organisation,
            email: this.props?.accountValues?.emailId,
            mobile: this.props?.accountValues?.mobile,
            custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : '',
            productName: this.state?.name ? this.state.name : '',
          };
          this.props.sentEmailForNonCA(payload);
        }
      }

      const analyticspayload = {
        productName: null,
        productType: 'partner product',
        partnerName: this.state.name,
        solutionName: this.state?.solution?.replace('~', '&'),
      };
      onSubscribeBtnClick(analyticspayload);
      if (Object.keys(this.props?.accountValues).length) {
        const payload = {
          firstName: this.props?.accountValues?.firstName,
          lastName: this.props?.accountValues?.lastName,
          organisation: this.props?.accountValues?.organisation,
          email: this.props?.accountValues?.emailId,
          mobile: this.props?.accountValues?.mobile,
          custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : '',
          productName: this.state?.name ? this.state.name : '',
        };
        this.props.sentEmailForNonCA(payload);
      }
    }
  }
  handleCloseSubscribe = () => {
    this.setState({ ...this.state, showSubscribe: false });
  };
  handleOkSubscribe = () => {
    this.setState({ ...this.state, showSubscribe: false });
    let payload = {
      name: this.state.name,
      productId: this.props.OverviewValues.productId,
    };
    this.props.checkSubscribe(payload);
  };
  handleOpenSubscribe() {
    if (!this.props.issubscribed.statusCode && !this.state.subscribedDone) {
      this.setState({ ...this.state, showSubscribe: true });
    } else if (this.props.issubscribed.statusCode == 200 || this.state.subscribedDone) {
      if (this.props.issubscribed.statusType == 'Not Updated') {
        this.setState({ ...this.state, openToast: true, subscribedDone: true });
        setTimeout(() => {
          window.open(this.props.OverviewValues.redirectURL);
        }, 2000);
      } else if (this.props.issubscribed.statusCode == 500) {
        this.setState({ ...this.state, showSubscribe_error: true });
      }
    }
  }
  handleCloseLogin = () => {
    this.setState({ ...this.state, showlogin: false });
  };
  handleToastOpen() {
    debugger;
    this.setState({ ...this.state, taosterShown: false }, () => {
      this.closeDisclaimer();
      let payload = {
        name: this.state.name,
        productId: this.props.OverviewValues.productId,
      };
      this.props.checkSubscribe(payload);
    });
  }
  handlefailToastOpen() {
    if (Object.keys(this.props?.accountValues).length) {
      const payload = {
        firstName: this.props?.accountValues?.firstName,
        lastName: this.props?.accountValues?.lastName,
        organisation: this.props?.accountValues?.organisation,
        email: this.props?.accountValues?.emailId,
        mobile: this.props?.accountValues?.mobile,
        custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : '',
        productName: this.state?.name ? this.state.name : '',
      };
      this.props.sentEmailForNonCA(payload);
    }
    this.setState({ ...this.state, showfailOpen: true });
  }
  handlefailToastClose() {
    this.setState({ ...this.state, showfailOpen: false });
  }
  handleToastClose() {
    this.setState({ ...this.state, openToast: false });
  }
  handleOpenVideo() {
    this.setState({ ...this.state, showVideo: true });
  }
  handleCloseVideo() {
    this.setState({ ...this.state, showVideo: false });
  }
  moveTo = (event) => {
    scroller.scrollTo(event);
  };
  handleAccord = (e) => {
    this.setState({ ...this.state, key: e });
  };

  handleModalOpen() {
    if (!localStorage.token) {
      globalClickEvent(`button clicked login`);
      this.props.openModal();
    } else {
      // check digital on board flag  if true  do thid
      debugger;
      if (this.props.digiOnboard) {
        this.setState({ ...this.state, modalAccount: true, disabledVerify: false, caNumber: '' });
      } else {
        const reqPayload = {
          custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : '',
          productName: this.state?.name ? this.state.name : '',
          productId: this.props.productId,
        };
        this.props.setError(undefined);
        this.props.checkSubscribe(reqPayload);
        window.open(this.props.OverviewValues.redirectURL);
        window.blur();

        if (Object.keys(this.props?.accountValues).length) {
          const payload = {
            firstName: this.props?.accountValues?.firstName,
            lastName: this.props?.accountValues?.lastName,
            organisation: this.props?.accountValues?.organisation,
            email: this.props?.accountValues?.emailId,
            mobile: this.props?.accountValues?.mobile,
            custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : '',
            productName: this.state?.name ? this.state.name : '',
          };
          this.props.sentEmailForNonCA(payload);
        }
      }
      globalClickEvent(`subscription button clicked`);
    }
  }
  handleModalClose() {
    this.setState({ ...this.state, modalAccount: false });
  }

  saveCaAccount(e) {
    this.setState({ ...this.state, caNumber: e.target.value });
  }

  makeVerify() {
    // debugger;
    if (this.state.caNumber || this.props?.accountValues?.custId) {
      this.setState({ ...this.state, disabledVerify: true, checkUser: 'SET', disclaimer: false, userVerified: false, useNew: true }, () => {
        this.props.verify_user(this.state.caNumber ? this.state.caNumber : this.props?.accountValues?.custId);
      });
    } else {
      this.setState({ ...this.state, userVerified: false, disabledVerify: false, error: { ...this.state.error, caError: 'Please Enter Customer ID' } });
    }
  }

  openDisclaimer() {
    this.setState({ ...this.state, disclaimer: true });
  }

  closeDisclaimer() {
    this.setState({ ...this.state, disclaimer: false });
  }

  showCurrentAccount() {
    this.setState({ ...this.state, isCustIdVisible: true });
  }
  hideCurrentAccount() {
    this.setState({ ...this.state, isCustIdVisible: false });
  }
  validateMobileNumber() {
    debugger;
    this.props.sendOtpLoaderAction(true);

    if (this.props?.verified_user?.mobile?.length > 0) {
      debugger;
      this.props.sendOtpCAUser(this.props?.verified_user?.custId);
    }
  }

  verifyClickNow() {
    // debugger;
    if (this.state?.details?.otp?.length === 6) {
      this.props.verifyOtp(this.state.details.otp);
      this.setState({ ...this.state, otpSent: true });
    } else {
      this.setState({ ...this.state, error: { otp: true }, otp_status: 'fail', otp_messgae: 'Please enter valid OTP' });
    }
  }
  render() {
    console.log('==offers======>', this.props);
    debugger;
    return (
      <>
        <Header />
        {this.state.showSubscribe_error ? <div className={'alert alert-danger'}>Some Network Error</div> : ''}
        <PartnerDetailbanner
          name={this.state.name}
          sol={this.state.solution.replace('~', '&')}
          handleOpenLogin={this.handleModalOpen.bind(this)}
          title={this.props.OverviewValues?.title}
          isSubscribed={this.props.isSubscribed}
          redirectURL={this.props.OverviewValues?.redirectURL}
        />

        <>
          <div id="over" className="overview-content">
            <div className="heading-overview">Overview</div>
            <div className={'overview-container'}>
              <div className={'overview-box'}>
                <div className="intro">{this.props.introduction}</div>
                {this.props.overviewFeatures &&
                  this.props.overviewFeatures.map((data) => <div className={'overviewBox'} dangerouslySetInnerHTML={{ __html: data }}></div>)}
              </div>
            </div>
          </div>
          <Offers offers={this.props.offer}></Offers>
          <div id="feature">
            <div className=" no-pad feature-container">
              <h1 className="feature-heading">Features </h1>
              <div className="feature-row row">
                <div className={'row justify-content-center'}>
                  {this.state?.features &&
                    this.state?.features[0].map((data, i) => (
                      <div className={'col-sm-4 mb-4'} key={i}>
                        <div className="body-container">
                          <div className="feature-data-container">
                            <label className="feature-label">
                              <img className="feature-icon" src="/assets/icons/arrow.png" />
                              {data.featureName}
                            </label>
                            <br />
                            <p className="feature-text">{data.description} </p>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
                {this.state?.features && this.state?.features[1].length ? (
                  <div className={'row justify-content-center'}>
                    {this.state?.features &&
                      this.state?.features[1].map((data, i) => (
                        <div className={'col-sm-4 mb-4'} key={i}>
                          <div className="body-container">
                            <div className="feature-data-container">
                              <label className="feature-label">
                                <img className="feature-icon" src="/assets/icons/arrow.png" />
                                {data.featureName}
                              </label>
                              <br />
                              <p className="feature-text">{data.description} </p>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                ) : (
                  ''
                )}
                {this.state?.features && this.state?.features[2].length ? (
                  <div className={'row justify-content-center  w-100'}>
                    {this.state?.features &&
                      this.state?.features[2].map((data, i) => (
                        <div className={'col-sm-4 mb-4'} key={i}>
                          <div className="body-container">
                            <div className="feature-data-container">
                              <label className="feature-label">
                                <img className="feature-icon" src="/assets/icons/arrow.png" />
                                {data.featureName}
                              </label>
                              <br />
                              <div className="feature-text" dangerouslySetInnerHTML={{ __html: data?.description }}></div>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                ) : (
                  ''
                )}
              </div>
            </div>
          </div>
        </>

        <div id="faq">
          <h1 className="faq-heading">
            FAQ - <br />
            Hi! How can we help you?{' '}
          </h1>

          {this.props.OverviewValues.faqs !== undefined && this.props.OverviewValues.faqs !== null
            ? this.props.OverviewValues.faqs.map((faq, index) => (
                <Accordion className="accord-container" defaultActiveKey="1" onSelect={(e) => this.handleAccord(e)}>
                  <Card>
                    <Accordion.Toggle className="accord-header" as={Card.Header} eventKey={index + 1}>
                      <span className="accord-title">Q.{index + 1}</span>{' '}
                      <div
                        className="accord-title"
                        dangerouslySetInnerHTML={{
                          __html: faq.question,
                        }}
                      ></div>
                      {this.state.key == index + 1 ? (
                        <img className="header-icon" src="assets/partner-page/upperArrow.svg" />
                      ) : (
                        <img className="header-icon" src="assets/partner-page/downArrow.svg" />
                      )}
                    </Accordion.Toggle>
                    <Accordion.Collapse eventKey={index + 1}>
                      <div className="border-section">
                        <Card.Body className="answer-container">
                          <div className="accord-text-spn">A.&nbsp;</div>
                          <div
                            className="accord-text"
                            dangerouslySetInnerHTML={{
                              __html: faq.answer,
                            }}
                          ></div>
                        </Card.Body>
                      </div>
                    </Accordion.Collapse>
                  </Card>
                </Accordion>
              ))
            : ''}
        </div>
        {this.props.OverviewValues?.videos && this.props.OverviewValues?.videos?.trim() && (
          <div id="video" className="video-container">
            {/* <h1 className="video-heading">Videos</h1> */}
            <div className="content-section">You can build, test and deploy your own customized API services through us.</div>
            <div className="image-section">
              <img
                className="video-content"
                width="100%"
                // src="/ybl-apihub-frontend/public/assets/partner-page/"
                src={`assets/partner-page/tumbnail/${String(this.state.name).trim().toLocaleLowerCase().replace(' ', '-')}.svg`}
                frameborder="0"
                allowfullscreen
                onClick={this.handleOpenVideo.bind(this)}
              ></img>
            </div>
          </div>
        )}
        {!(this.props.accountValues.productDescription && this.props.accountValues.solutionName) && (
          <div className="footer-container">
            {/* <h1 className="become-partner" onClick={this.handleOpenLogin.bind(this)}>
              <span> Become a Partner </span>
            </h1> */}
            <div className="left-partner-content">
              <p className="become-partner-content partner-details">
                Develop customized solutions with YES BANK for enhanced customer experience and showcase your product on YES Connect.
              </p>
              <Button className="register-now-button partner-btn" onClick={this.handleOpen.bind(this)}>
                Become a Partner
              </Button>
            </div>
            <div className={'partnerImgage'}>
              <img src={'assets/partner-page/become-partner.svg'} />
              <Button className="register-now-button partner-btn mobile-btn" onClick={this.handleOpen.bind(this)}>
                Become a Partner
              </Button>
            </div>
          </div>
          // ) : this.props.accountValues.productDescription !== null && this.props.accountValues.solutionName !== null ? (
          //   <div className="footer-container partner-details">
          //     {/* <h1 className="become-partner" onClick={this.handleOpen.bind(this)}>
          //       <span> Become a Partner </span>
          //     </h1> */}
          //     <div className="left-partner-content">
          //       <p className="become-partner-content productDescription">
          //         Develop customized solutions with YES BANK for enhanced customer experience and showcase your product on YES Connect.
          //       </p>
          //       <Button className="register-now-button partner-btn" onClick={this.handleOpen.bind(this)}>
          //         Become a Partner
          //       </Button>
          //     </div>
          //     <div className={'partnerImgage'}>
          //       <img src={'assets/partner-page/become-partner.svg'} />
          //       <Button className="register-now-button partner-btn mobile-btn" onClick={this.handleOpen.bind(this)}>
          //         Become a Partner
          //       </Button>
          //     </div>
          //   </div>
          // ) : (
          //   ''
          // )
        )}

        <Footer />
        <Modal className={'videoModal'} size={'xl'} show={this.state.showVideo} onHide={this.handleCloseVideo.bind(this)}>
          <Modal.Header className="no-border" closeButton></Modal.Header>
          <Modal.Body>
            <iframe width="100%" height="450" src={this.props.OverviewValues.videos} frameborder="0" allowfullscreen></iframe>
          </Modal.Body>
        </Modal>

        <Modal className={'accountModal'} show={this.state.modalAccount} onHide={this.handleModalClose.bind(this)}>
          <Modal.Header className="no-border" closeButton>
            <h3 className="heading3 no-margin">Subscribe Details</h3>
          </Modal.Header>
          <Modal.Body>
            {this.props.issubscribed.statusCode == 200 && (
              <Alert variant="success">
                Thank you for subscribing to {this.state.name}. You will receive an email on your registered email ID to complete the onboarding process for
                your bank account. Please follow the link in the email to complete the setup for your bank account
              </Alert>
            )}
            {this.props.issubscribed.statusCode != 200 && (
              <>
                <div className="col-md-12 m-t-40 m-bottom-20">
                  <p className="radio-title">
                    {this.props?.accountValues?.custId
                      ? 'Do you want to link your current account to the Partner application?'
                      : 'Do you have YES BANK Current Account?.'}

                    <span className="required">*</span>
                  </p>
                  <Radio
                    label={'Yes'}
                    id="caAccount"
                    onClick={this.showCurrentAccount.bind(this)}
                    value="yes"
                    name="account-title"
                    checked={this.state.isCustIdVisible}
                  />
                  <Radio label={'No'} onClick={this.hideCurrentAccount.bind(this)} value="no" name="account-title" checked={!this.state.isCustIdVisible} />
                </div>
                {this.state.isCustIdVisible && (
                  <>
                    <div className="col-md-12 m-t-40 m-bottom-35">
                      {/* {this.state.error.caError ? <p className="text-danger no-margin">{this.state.error.caError}</p> : null} */}

                      <Input
                        label={'CustID'}
                        onChange={this.saveCaAccount.bind(this)}
                        required
                        name="custID"
                        // value={this.state.caNumber}
                        value={this.state.caNumber ? this.state.caNumber : this.props?.accountValues?.custId}
                        defaultValue={this.props?.accountValues?.custId ? this.props?.accountValues?.custId : ''}
                        disabled={this.props?.accountValues?.custId ? true : false}
                      />
                      {/* )} */}
                      {this.props?.verify_user_state == 'success' && this.state.isCustIdVisible && (
                        <span className="success">{this.props?.verify_messgae}</span>
                      )}
                      {this.props?.verify_user_state == 'fail' && this.state.isCustIdVisible && <span className="error">{this.props?.verify_messgae}</span>}
                      {this.state?.isCustIdError &&
                        this.state.isCustIdVisible &&
                        this.props?.verify_user_state != 'fail' &&
                        this.props?.verify_user_state != 'success' && <span className="error">{this.state.custErrorMsg}</span>}

                      <Button
                        onClick={this.makeVerify.bind(this)}
                        className={`verify-btn pull-right ${this.state.disabledVerify ? 'disabled' : ''}`}
                        variant="link"
                      >
                        Verify
                        {this.props.caLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
                      </Button>
                    </div>

                    <div className="col-md-12 m-t-40 m-bottom-20 display-flex">
                      <Form.Control as="select" disabled={true} value={'91'} className="phone-code">
                        <option value={'91'}>+{'91'}</option>;
                      </Form.Control>
                      <PhoneNumber
                        id="phoneno"
                        showLoader={this.props.sendOtpLoader}
                        // otpDisabled={this.state.otpDisabled}
                        otpDisabled={false}
                        timeStr={this.state.otpTime}
                        otpText={this.state.OtpText}
                        label={'Mobile Number'}
                        value={this.props?.verified_user?.mobile}
                        required
                        name="mobile"
                        error={this.state.error.mobile}
                        disableSendOtpLink={this.props?.verified_user?.mobile?.length > 0}
                        onChange={this.saveValue.bind(this, 'mobile')}
                        otpClick={this.validateMobileNumber.bind(this)}
                        disabled={true}
                      />
                    </div>

                    <div className="col-md-12 m-t-40 m-bottom-20">
                      <Otp
                        id="otp"
                        label={'Otp'}
                        showLoader={this.props?.verifyOtpLoader}
                        otpDisabled={this.props.otpStatus == 'success'}
                        verifyState={this.props.otpStatus}
                        verifyMsg={this.props.otp_success_msg}
                        verifyClick={this.verifyClickNow.bind(this)}
                        error={this.state.error.otp}
                        onChange={this.saveValue.bind(this, 'otp')}
                        disabled={!this.state.otpSent || this.props.otpStatus == 'success'}
                        required
                        name="otp"
                        value={this.state.otp}
                      />
                      {this.state.otp_status == 'fail' && !this.props.otpStatus && <span className="error">{this.state.otp_messgae}</span>}
                    </div>
                    <div className="col-md-12 m-t-40 m-bottom-20">
                      <Input
                        label={'Name'}
                        name="Name"
                        value={`${this.props?.verified_user?.firstName ? this.props?.verified_user?.firstName : ''} 
                    ${this.props?.verified_user?.lastName ? this.props?.verified_user?.lastName : ''}`}
                        defaultValue={`${this.props?.verified_user?.firstName ? this.props?.verified_user?.firstName : ''} 
                    ${this.props?.verified_user?.lastName ? this.props?.verified_user?.lastName : ''}`}
                        disabled={true}
                      />
                    </div>
                    <div className="col-md-12 m-t-40 m-bottom-20">
                      <Input
                        label={'Email'}
                        name="email"
                        value={`${this.props?.verified_user?.emailId ? this.props?.verified_user?.emailId : ' '}`}
                        defaultValue={`${this.props?.verified_user?.emailId ? this.props?.verified_user?.emailId : ' '}`}
                        disabled={true}
                      />
                    </div>
                  </>
                )}
              </>
            )}
            {!this.state.isCustIdVisible && this.props.issubscribed.statusCode != 200 && (
              <>
                <div className="col-md-12 m-t-40 m-bottom-20">
                  <Input
                    label={'First Name'}
                    name="firstname"
                    value={this.props?.accountValues?.firstName}
                    defaultValue={this.props?.accountValues?.firstName}
                    disabled={true}
                  />
                </div>
                <div className="col-md-12 m-t-40 m-bottom-20">
                  <Input
                    label={'Last Name'}
                    name="lastname"
                    value={this.props?.accountValues?.lastName}
                    defaultValue={this.props?.accountValues?.lastName}
                    disabled={true}
                  />
                </div>
                <div className="col-md-12 m-t-40 m-bottom-20">
                  <Input
                    label={'Email Id'}
                    name="email"
                    value={this.props?.accountValues?.emailId}
                    defaultValue={this.props?.accountValues?.emailId}
                    disabled={true}
                  />
                </div>
                <div className="col-md-12 m-t-40 m-bottom-20">
                  <Input
                    label={'Phone No'}
                    name="phoneno"
                    value={this.props?.accountValues?.mobile}
                    defaultValue={this.props?.accountValues?.mobile}
                    disabled={true}
                  />
                </div>
              </>
            )}
            <div className="col-md-12 m-t-40 m-bottom-20">{this.props.partnerError && <Alert variant="danger">{this.props.partnerError}</Alert>}</div>
            {this.props.issubscribed.statusCode != 200 && (
              <div className="col-md-12 m-t-40 m-bottom-20">
                <Button className="submit-btn pull-right" variant="default" onClick={this.handleSubscrption.bind(this)}>
                  Subscribe {this.props.parterLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true"></Spinner>}
                </Button>
              </div>
            )}
          </Modal.Body>
        </Modal>

        <Modal className={'accountModal'} show={this.state.disclaimer} onHide={this.closeDisclaimer.bind(this)}>
          <Modal.Header closeButton>
            <h3 className="heading3 no-margin">Disclaimer</h3>
          </Modal.Header>
          <Modal.Body>
            <div className="col-md-12 m-t-40">
              <br />
              <br />
              By clicking on the Button, you will be leaving yesbank.in and entering website operated by other third parties. YES BANK Limited does not control
              or endorse such websites, and bears no risk or responsibility for them.
              <br />
              <br />
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button className="submit-btn pull-right" variant="default" onClick={this.handleToastOpen.bind(this)}>
              Ok Proceed
            </Button>
          </Modal.Footer>
        </Modal>

        <Toast
          show={this.state.showfailOpen}
          style={{
            position: 'absolute',
            top: 80,
            right: 40,
            maxWidth: 434,
          }}
        >
          <Toast.Header className="d-flex to-header">
            <img src="/assets/icons/Icon Success.svg" className="toast-icon" alt="" />
            <span className="to-text">
              Thank you for showing interest in our partner product.You will be able to subscribe once your current account is active.Please call our helpline
              number 12345678 for further assistance on current account status.
            </span>
            <span className="to-dismiss" onClick={this.handlefailToastClose.bind(this)}>
              Dismiss
            </span>
          </Toast.Header>
        </Toast>

        <Toast
          show={this.state.openToast}
          style={{
            position: 'absolute',
            top: 80,
            right: 40,
            maxWidth: 434,
          }}
        >
          <Toast.Header className="d-flex to-header">
            <img src="/assets/icons/Icon Success.svg" className="toast-icon" alt="" />
            <span className="to-text">You have previously successfully re-directed to this partner website</span>
            <span className="to-dismiss" onClick={this.handleToastClose.bind(this)}>
              Dismiss
            </span>
          </Toast.Header>
        </Toast>
        {/* <Modal
          className={"loginModal"}
          show={this.state.showSubscribe}
          onHide={this.handleCloseSubscribe.bind(this)}
        >
          <Modal.Header className="login-header">
            Subscribe
            <button type="button" class="close">
              <span aria-hidden="true">
                <img
                  alt="icon"
                  className="close-icon"
                  src="/assets/icons/login-close.svg"
                  onClick={this.handleCloseSubscribe.bind(this)}
                />
              </span>
              <span class="sr-only">Close</span>
            </button>
          </Modal.Header>
          <Modal.Body>
            {!this.props.OverviewValues.redirectURL ? (
              <div className={"alert alert-danger"}>
                No redirect url exists.
              </div>
            ) : (
                <>
                  <p className="m-text">
                    {" "}
              You will be redirected to the partners website for subscription. Select OK to
              proceed:
            </p>
                  <a href={this.props.OverviewValues.redirectURL} target="_blank">
                    {" "}
                    <Button
                      variant="primary"
                      className="ok-btn"
                      onClick={this.handleCloseSubscribe.bind(this)}
                    >
                      OK{" "}
                    </Button>
                  </a>
                </>
              )}
          </Modal.Body>
        </Modal> */}
        <Modal className={'loginModal'} show={this.state.openPopup} onHide={this.handleClose.bind(this)}>
          <Modal.Header className="login-header">
            Save
            <button type="button" class="close">
              <span aria-hidden="true">
                <img alt="icon" className="close-icon" src="/assets/icons/login-close.svg" onClick={this.handleClose.bind(this)} />
              </span>
              <span class="sr-only">Close</span>
            </button>
          </Modal.Header>
          <Modal.Body>
            <div className="text-section">
              {this.props.updateLogin > 1 ? (
                <>
                  <div className={'alert alert-primary'}>Thank you for choosing to partner with us. Our Team will be in touch with you for more details.</div>
                </>
              ) : (
                ''
              )}
              <Input
                label={'Product/Solution Name'}
                onChange={this.saveValue.bind(this, 'solname')}
                error={this.state.error.solname}
                required
                maxlength="35"
                name="solname"
                id="solname"
                value={this.state.details.solname}
                defaultValue={this.state.details.solname}
              />
            </div>
            <div className="text-section">
              <Input
                label={'Short description'}
                onChange={this.saveValue.bind(this, 'desc')}
                error={this.state.error.desc}
                required
                maxlength="300"
                name="desc"
                id="desc"
                value={this.state.details.desc}
                defaultValue={this.state.details.desc}
              />
            </div>
            <div className="action-section">
              <Button className="submit-btn" variant="primary" onClick={this.handleLogin.bind(this)}>
                Become a Partner
              </Button>
              <Button className="cancel-btn" variant="default" onClick={this.handleClose.bind(this)}>
                Cancel
              </Button>
            </div>
            {/* <p className="reg">
              {" "}
              Not a Registered user?{" "}
              <a className="link" href="/register">
                Register
              </a>{" "}
            </p> */}
          </Modal.Body>
        </Modal>
      </>
    );
  }
}
// overviewFeatures: state.partnerProductReducer.overview.overviewFeatures,

const mapStateToProps = (state) => ({
  accountValues: state.accountReducer.accountDetails,
  partnerProducts: state.partnerReducer.Partnerproducts,
  updateLogin: state.partnerReducer.updatePartner,
  error_update: state.partnerReducer.error_update,
  OverviewValues: state.partnerProductReducer.overview,
  features: state.partnerProductReducer.features,
  issubscribed: state.partnerProductReducer.checksubscribe,
  verify_messgae: state.partnerProductReducer.verified_message,
  verified_user: state.partnerProductReducer.verified_user,
  random: state.partnerProductReducer.verified_user,
  verify_user_state: state.partnerProductReducer.verify_user_state,
  introduction: state.partnerProductReducer.overview.introduction,
  overviewFeatures: state.partnerProductReducer.overview.overviewFeatures,
  partnerError: state.partnerProductReducer.error,
  parterLoader: state.partnerProductReducer.parterLoader,
  caLoader: state.partnerProductReducer.caLoader,
  offer: state.partnerProductReducer.overview.offer,
  sendOtpLoader: state.partnerProductReducer.sendOtpLoader,
  isOtpSent: state.partnerProductReducer.sendOTPStatus,
  otpStatus: state.partnerProductReducer.otp_verify_state,
  otp_success_msg: state.partnerProductReducer.otp_text_msg,
  isSubscribed: state.partnerProductReducer.isSubscribed,
  digiOnboard: state.partnerProductReducer.overview.digiOnboard,
  productId: state.partnerProductReducer.overview.productId,
});
const mapDispatchToProps = (dispatch) => {
  return {
    getAccountData: () => dispatch(getAccountData()),
    updatePartner: (obj) => dispatch(updatePartner(obj)),
    getOverview: (id) => dispatch(getOverview(id)),
    getFeatures: (id) => dispatch(getFeatures(id)),
    checkSubscribe: (payload) => dispatch(checkSubscribe(payload)),
    openModal: () => dispatch(loginModalStatus(true)),
    sentEmailForNonCA: (payload) => dispatch(sentEmailForNonCA(payload)),
    verify_user: (payload) => dispatch(verifyCa(payload)),
    sendOtpCAUser: (custId) => dispatch(sendOtpCAUser(custId)),
    verifyOtp: (otp) => dispatch(verifyOtp(otp)),
    sendOtpLoaderAction: (flag) => dispatch(sendOtpLoaderAction(flag)),
    setError: (msg) => dispatch(setError(msg)),
    subscribeAction: (id, token) => dispatch(subscribeAction(id, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(partnerDetail);

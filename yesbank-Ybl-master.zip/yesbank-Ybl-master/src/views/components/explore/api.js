import axios from 'axios';
import { APIURL } from '../../../env';

const getPartnerCategory = () => {
  var response = axios.get(window.yblDomain + '/ybl/getPartnerCategory');
  return response;
};

const fetchTagsSolutions = (params) => {
  let fsearchKey = params.tags.toString();
  let searchKey = fsearchKey.toLowerCase();
  let value = '';
  if (params.boolean === true) {
    value = 'yblProduct';
  } else if (params.boolean === false) {
    value = 'partner';
  } else if (params.boolean === '') {
    value = '';
  }
  var config = {
    searchKey: searchKey,
    filter: value,
  };
  console.log('insidefetchsolutions', params.boolean);
  let tagsresponse = axios.post(`${window.yblDomain}/apihub/search/searchDetails`, config);
  return tagsresponse;
};

const fetchSolutions = () => {
  var response = axios.get(window.yblDomain + '/apihub/explore/products');
  return response;
};

export { fetchSolutions, fetchTagsSolutions, getPartnerCategory };

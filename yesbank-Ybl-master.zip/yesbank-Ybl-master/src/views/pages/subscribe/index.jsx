import React, { Component } from 'react';
import Header from '../../layout/header';
import Footer from '../../layout/footer';
import Subscribe  from '../../components/subscribe/index'
class Index extends Component {
  constructor(props) {
    super(props)
    this.state = {
        ...props
    }
  }

  render() {
    return (
      <div>
        <Header/>
        <Subscribe/>
        <Footer/>
      </div>
    )
  }
}

export default Index
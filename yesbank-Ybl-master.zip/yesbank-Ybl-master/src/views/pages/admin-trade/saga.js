import { all, takeEvery, put } from 'redux-saga/effects';
import {
  FETCH_TRADE,
  FETCH_TRADE_SUCCESS,
  FETCH_TRADE_FAIL,
  ACCEPT_TRADE,
  ACCEPT_TRADE_FAIL,
  ACCEPT_TRADE_SUCCESS,
  DECLINE_TRADE,
  DECLINE_TRADE_SUCCESS,
  DECLINE_TRADE_FAIL,
} from './constant';
import { get_trade } from './apis';

export function* fetchTRADEAsync({ payload }) {
  try {
    const token = localStorage.getItem('adminToken');
    let { data } = yield get_trade(payload, token);
    if (data.statusType != 'SUCCESS') {
      yield put({ type: FETCH_TRADE_FAIL, data });
    } else {
      yield put({ type: FETCH_TRADE_SUCCESS, data });
    }
  } catch (err) {
    if (err?.response?.data?.error === 'Unauthorized' || err.response.status === 401) {
      localStorage.setItem('AdminAccess', 'No');
      window.location.href = `${window.location.origin}/admins`;
    }
    yield put({ type: 'NETWORK ERROR' });
  }
}

// export function* acceptTRADEAsync(payload) {
//     try {
//         const token = localStorage.getItem("adminToken");
//         let { data } = yield accept_trade(payload,token);
//         console.log(data,'pkpk')
//         if (data.statusType != 'SUCCESS') {
//             yield put({ 'type': ACCEPT_TRADE_FAIL, data: data?.message })
//         } else {
//             yield put({ 'type': ACCEPT_TRADE_SUCCESS, data });
//         }
//     } catch(err) {
//         if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
//             localStorage.setItem("AdminAccess","No")
//             window.location.href=`${window.location.origin}/admins`

//         }
//         yield put({ 'type': 'NETWORK ERROR' })
//     }
// }

// export function* declineTradeAsync(payload) {
//     try {
//         const token = localStorage.getItem("adminToken");
//         let { data } = yield decline_trade(payload,token);
//         if (data.statusType != 'SUCCESS') {
//             yield put({ 'type': DECLINE_TRADE_FAIL, data: data?.message })
//         } else {
//             yield put({ 'type': DECLINE_TRADE_SUCCESS, data });
//         }
//     } catch (err){
//         if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
//             localStorage.setItem("AdminAccess","No")
//             window.location.href=`${window.location.origin}/admins`

//         }
//         yield put({ 'type': 'NETWORK ERROR' })
//     }
// }

export default function* watchAll() {
  yield all([
    takeEvery(FETCH_TRADE, fetchTRADEAsync),
    // takeEvery(ACCEPT_TRADE, acceptTradeAsync),
    // takeEvery(DECLINE_LEAD, declineTradeAsync),
  ]);
}

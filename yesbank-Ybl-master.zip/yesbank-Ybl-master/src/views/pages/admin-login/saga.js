import { all, takeEvery, put } from 'redux-saga/effects';
import { MAKE_LOGIN, MAKE_LOGIN_SUCCESS, MAKE_LOGIN_FAIL, CREATE_ADMIN_CAPTCHA, MAKE_VERIFY_ADID, MAKE_REFRESH_CAPTCHA } from './constant';
import { make_login, make_verify, make_refreshcaptcha } from './apis';

export function* makeLoginAsync({ payload }) {
  try {
    let { data } = yield make_login(payload);
    if (data.statusType != 'SUCCESS') {
      yield put({ type: MAKE_LOGIN_FAIL, data });
    } else {
      yield put({ type: MAKE_LOGIN_SUCCESS, data });
      localStorage.removeItem('AdminAccess');
    }
  } catch {
    yield put({ type: MAKE_LOGIN_FAIL });
  }
}

export function* makeVerifyAsync({ payload }) {
  try {
    let res = yield make_verify(payload);
    let { data } = res;
    if (data.statusType != 'SUCCESS') {
      yield put({ type: MAKE_LOGIN_FAIL, data });
      yield put({ type: CREATE_ADMIN_CAPTCHA, payload: '' });
    } else {
      yield put({ type: CREATE_ADMIN_CAPTCHA, payload: data?.response.captcha });
      localStorage.setItem('sessionId', res.headers.sessionid);
    }
  } catch {
    yield put({ type: MAKE_LOGIN_FAIL });
    yield put({ type: CREATE_ADMIN_CAPTCHA, payload: '' });
  }
}

export function* makeRefreshTokenAsync({ payload }) {
  try {
    let res = yield make_refreshcaptcha(payload);
    let { data } = res;
    if (data.statusType != 'SUCCESS') {
      yield put({ type: MAKE_LOGIN_FAIL, data });
      yield put({ type: CREATE_ADMIN_CAPTCHA, payload: '' });
    } else {
      yield put({ type: CREATE_ADMIN_CAPTCHA, payload: data?.response.captcha });
      localStorage.setItem('sessionId', res.headers.sessionid);
    }
  } catch {
    yield put({ type: MAKE_LOGIN_FAIL });
    yield put({ type: CREATE_ADMIN_CAPTCHA, payload: '' });
  }
}

export default function* watchAll() {
  yield all([takeEvery(MAKE_LOGIN, makeLoginAsync), takeEvery(MAKE_VERIFY_ADID, makeVerifyAsync), takeEvery(MAKE_REFRESH_CAPTCHA, makeRefreshTokenAsync)]);
}

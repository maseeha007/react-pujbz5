import { FETCH_CASUBSCRIPTION_FAIL, FETCH_CASUBSCRIPTION_SUCCESS, ACCEPT_CASUBSCRIPTION_SUCCESS, ACCEPT_CASUBSCRIPTION_FAIL, DECLINE_CASUBSCRIPTION_FAIL, DECLINE_CASUBSCRIPTION_SUCCESS,SET_CANCEL_ACTION_SUCCESS } from './constant';


export default function storeCases(state = {}, action) {
  switch (action.type) {
    case FETCH_CASUBSCRIPTION_FAIL:
      return { ...state, error_msg: action.data?.response }
    case FETCH_CASUBSCRIPTION_SUCCESS:
      return { ...state, subscriptionList: action.data.response.subscriptionList, subdata: action.data.response.subscriptionCount, error_msg: null }
    case ACCEPT_CASUBSCRIPTION_FAIL:
      return { ...state, error_msg: "Unable to Update, Some Server Error Occurred", success_msg: null }
    case ACCEPT_CASUBSCRIPTION_SUCCESS:
      return { ...state, success_msg: "Accepted Successfully with ID: "+action.data.response, error_msg: null }
      case DECLINE_CASUBSCRIPTION_FAIL:
      return { ...state, error_msg: "Unable to Update, Some Server Error Occurred", success_msg: null }
    case DECLINE_CASUBSCRIPTION_SUCCESS:
      return { ...state, success_msg: "Declined Successfully with ID: "+action.data.response, error_msg: null }
    case SET_CANCEL_ACTION_SUCCESS:
        return { ...state, success_msg: null, error_msg: null }
    default:
      return state
  }
}


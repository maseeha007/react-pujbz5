import React, { Component } from 'react';
import Header from '../../layout/header';
import Banner from '../../components/banner';
import Solutions from '../../components/solutions';
import Logolist from '../../components/logolist';
import Testimonials from '../../components/testimonials';
import Footer from '../../layout/footer';
import SucessStories from '../../components/sucesstories';
import "./style.scss";
import 'react-captchaa/dist/index.css';
import { onLoadTrack } from '../../../analytics';

class Index extends Component {
  constructor(props) {
    super(props)
    this.state = {
      ...props
    }
  }
  componentDidMount() {
    const payload = {
      pageName: 'yes connect|home',
      loginStatus: localStorage.getItem("userName") ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem("userLogin") === "PMS" ? 'employee' : 'non-employee',
      userId: localStorage.getItem("userId")

    }
    onLoadTrack(payload);
  }
  render() {
    return (
      <div id="home-section">
        <Header title="Home" />
        <Banner />
        <Solutions />
        <SucessStories />
        <Logolist />
        <Testimonials />
        <Footer />

      </div>
    )
  }
}

export default Index

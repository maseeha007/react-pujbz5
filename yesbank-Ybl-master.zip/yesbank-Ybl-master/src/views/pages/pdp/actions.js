import { GET_OVERVIEW,GET_FEATURES,GET_API_VERSION,GET_API_DEF,SET_TAB } from './constant';



export const getProductOverview = (id) => ({
  type: GET_OVERVIEW,
  payload: { id }
})

export const getProductFeatures = (id) => ({
  type: GET_FEATURES,
  payload: { id }
})
export const getAPIVersions = (id) => ({
  type: GET_API_VERSION,
  payload: { id }
})
export const getAPIDefination = (id,token) => ({
  type: GET_API_DEF,
  payload: { id,token }
})
export const setTab = (name) =>({
  type:SET_TAB,
  payload: {name}
})


import { SET_MODAL_STATUS, LOGOUT_SUCCESS,SET_SESSION_MODAL_STATUS } from './constant';
export default function storeCases(state = {loginModal: false}, action) {
  switch (action.type) {
    case SET_MODAL_STATUS : 
      return {...state,  loginModal: action.payload};
      case SET_SESSION_MODAL_STATUS : 
      return {...state,  sessionModal: action.payload};   
    case LOGOUT_SUCCESS : 
      return {...state,  logout_status: true};
    default:
    return state
  }
}


import { all, put, takeEvery, call } from 'redux-saga/effects'

import { LOGOUT_FAIL, LOGOUT_SUCCESS, LOGOUT_START} from './constant';
import { make_logout } from './apis';

export function* makeLogoutAsync() {
    try {
        let { data } = yield call(make_logout.bind(this));
        if(data.statusType!='SUCCESS'){
            yield put({'type': LOGOUT_FAIL, data: data.response})
        } else {
            yield   put({'type':LOGOUT_SUCCESS, data: data.response})
        }
    }  catch(error) {
            yield put({'type': LOGOUT_FAIL, data: { result : 'NETWORK ERROR' }})
    }    
}

export default function* watchAll() {
    yield all([
        takeEvery(LOGOUT_START,makeLogoutAsync),
    ])
    
}
import { SET_MODAL_STATUS , LOGOUT_START } from './constant';

export const loginModalStatus = (flag) => ({
    type: SET_MODAL_STATUS,
    payload: flag
})

export const makeLogout = () => ({
  type: LOGOUT_START,
  payload: {}
})

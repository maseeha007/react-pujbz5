import React, { Component, lazy, Suspense } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../node_modules/animate.css/source/animate.css';
import './main.scss';
import history from './history';
import * as yaml from 'yamljs';
class App extends Component {
  componentDidMount() {
    if (!localStorage.getItem('yblDomain')) {
      fetch('/domain.txt', {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
      })
        .then(function (response) {
          return response.json();
        })
        .then(function (myJson) {
          if (myJson.domain === 'QA') {
            // localStorage.setItem('yblDomain', 'http://api.636018471a4e4806a6f8.southeastasia.aksapp.io');
            // window.yblDomain = 'http://api.636018471a4e4806a6f8.southeastasia.aksapp.io';
            localStorage.setItem('yblDomain', 'https://uatyesconnect.yesbank.in');
            window.yblDomain = 'https://uatyesconnect.yesbank.in';
          }
          if (myJson.domain === 'UAT') {
            localStorage.setItem('yblDomain', 'https://uatyesconnect.yesbank.in');
            window.yblDomain = 'https://uatyesconnect.yesbank.in';
          }
          if (myJson.domain === 'PROD') {
            localStorage.setItem('yblDomain', 'https://yesconnect.yesbank.in');
            window.yblDomain = 'https://yesconnect.yesbank.in';
          }
        });
    } else {
      window.yblDomain = localStorage.getItem('yblDomain');
    }
  }

  render() {
    return (
      <Provider store={store}>
        <Router basename={window.yblDomain} history={history}>
          <Suspense fallback={<h1 className="text-center">Loading</h1>}>
            <Switch>
              <Route exact path="/" component={lazy(() => import('./views/pages/home'))} />
              <Route exact path="/explore" component={lazy(() => import('./views/components/institutions/institutions'))} />
               <Route exact path="/explore-listing" component={lazy(() => import('./views/components/explore-listing/explore'))} /> 
              <Route exact path="/explore/:path" component={lazy(() => import('./views/components/explore-path/explore'))} />
              <Route exact path="/register" component={lazy(() => import('./views/pages/register'))} />
              <Route exact path="/subscribe" component={lazy(() => import('./views/pages/subscribe'))} />
              <Route exact path="/product" component={lazy(() => import('./views/pages/pdp'))} />
              <Route exact path="/account" component={lazy(() => import('./views/components/account'))} />
              <Route exact path="/subscription-list" component={lazy(() => import('./views/components/subscriptionDetails'))} />
              {/* <Route exact path="/partner-products" component={lazy(() => import('./views/components/partnerProducts'))} /> */}
              <Route exact path="/Trade" component={lazy(() => import('./views/components/blog'))} />
              <Route exact path="/partnerdetails" component={lazy(() => import('./views/components/partnerDetails'))} />
              <Route exact path="/yesxpressonboarding" component={lazy(() => import('./views/components/partners'))} />
              <Route exact path="/terms-conditions" component={lazy(() => import('./views/components/termsConditions'))} />
              <Route exact path="/policy" component={lazy(() => import('./views/components/privacyPolicy'))} />
              <Route exact path="/about" component={lazy(() => import('./views/components/aboutApihub'))} />
              <Route exact path="/admins" component={lazy(() => import('./views/pages/admin-login'))} />
              <Route exact path="/admins/subscriptions" component={lazy(() => import('./views/pages/admin-subscriptions'))} />
              <Route exact path="/admins/subscriptions/cancel" component={lazy(() => import('./views/pages/admin-subscriptions-cancel'))} />
              <Route exact path="/admins/leads" component={lazy(() => import('./views/pages/admin-leads'))} />
              <Route exact path="/admins/partner-leads" component={lazy(() => import('./views/pages/admin-partner-leads'))} />
              <Route exact path="/admins/trade" component={lazy(() => import('./views/pages/admin-trade'))} />
              <Route exact path="/faq" component={lazy(() => import('./views/components/support'))} />
              <Route exact path="/getStarted" component={lazy(() => import('./views/components/howItWorks'))} />
              <Route exact path="/error" component={lazy(() => import('./views/pages/error'))} />
            </Switch>
          </Suspense>
        </Router>
      </Provider>
    );
  }
}

export default App;

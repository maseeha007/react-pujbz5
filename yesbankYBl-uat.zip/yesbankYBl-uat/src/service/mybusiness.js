export const myBusinessObj = [
  {
    key: 'Startup Toolkit',
    value: 'Payments API, Collections, Vakilsearch, Decentro, Nupay,Tyke',
  },
  {
    key: 'Manufacturing',
    value: 'Payments API, Collections, Accounting, payroll, inventory, invoicing, Zoho,Hylobiz,Vakilsearch, Cleartax,Cashfree, Open',
  },
  {
    key: 'Education',
    value: 'Feesbuzz, Cashfree, Open, PayU',
  },
  {
    key: 'Ecommerce',
    value: 'Payments API, Cashfree, Open, PayU',
  },
  {
    key: 'Freelancers',
    value: 'Open',
  },
  {
    key: 'NBFCs',
    value: 'NACH, Payments API,AutoCloud, OneFin,Signzy, Karza, Docboyz',
  },
  {
    key: 'Traders & Dealers',
    value: 'Payments API, Collections Inventory, Zoho,Hylobiz,Vakilsearch, Cleartax, Cashfree, Open',
  },
];

import CryptoJS from 'crypto-js';
import {AESKEY} from './../env'
const encryptedBase64Key = AESKEY;
const parsedBase64Key = CryptoJS.enc.Base64.parse(encryptedBase64Key);
export const encryptedData = (plaintText) => {
    let encryptedData = null;
    // Encryption process
    encryptedData = CryptoJS.AES.encrypt(plaintText, parsedBase64Key, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });
    console.log( "encryptedData=======>" + encryptedData );
    return encryptedData;
    //console.log( "encryptedData = " + encryptedData );
}
export const decryptedData = (encryptedCipherText) => {

    // Decryption process
    // const encryptedCipherText = "U2WvSc8oTur1KkrB6VGNDmA3XxJb9cC+T9RnqT4kD90="; // or encryptedData;
    const decryptedData = CryptoJS.AES.decrypt(encryptedCipherText, parsedBase64Key, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });
    console.log("DecryptedData = " + decryptedData);
    // this is the decrypted data as a string
    const decryptedText = decryptedData.toString(CryptoJS.enc.Utf8);
    console.log("DecryptedText = " + decryptedText);
    return decryptedText
}
import axios from 'axios';
import { APIMiddLEWAREURL } from '../../../env';

export const make_login = (payload) => {
  const data = { userName: payload.username, password: payload.password, captcha: payload.captcha };
  let header = {};
  if (localStorage.getItem('sessionId')) {
    header = { headers: { sessionid: localStorage.getItem('sessionId') } };
  }
  // todo set header for session id
  return axios.post(`${window.yblDomain}` + '/admin/login', data, header);
};

export const make_verify = (payload) => {
  const data = { userName: payload.username };

  return axios.post(`${window.yblDomain}` + '/admin/verify', data);
};
export const make_refreshcaptcha = () => {
  //   const data = { userName: payload.username };
  let header = {};
  if (localStorage.getItem('sessionId')) {
    header = { headers: { sessionid: localStorage.getItem('sessionId') } };
  }
  return axios.get(`${window.yblDomain}` + '/admin/refreshCaptcha', header);
};
// admin/verify'
// /admin/refreshCaptcha

import { MAKE_LOGIN_SUCCESS, MAKE_LOGIN_FAIL, CREATE_ADMIN_CAPTCHA } from './constant';

export default function storeCases(state = {}, action) {
  switch (action.type) {
    case MAKE_LOGIN_FAIL:
      return { ...state, error_msg: 'Invalid credentials' };
    case MAKE_LOGIN_SUCCESS:
      return { ...state, login_details: action.data.response, error_msg: null };
    case CREATE_ADMIN_CAPTCHA:
      return { ...state, captcha: action.payload };
    default:
      return state;
  }
}

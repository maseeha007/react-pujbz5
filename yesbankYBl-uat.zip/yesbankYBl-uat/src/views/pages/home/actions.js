import { FETCH_YML } from '../../../service/ApiLinks';



export const fetchYml = () => ({
  type: FETCH_YML,
  payload: {}
})



import { GET_OVERVIEW_DATA,GET_FEATURES_DATA,GET_API_VERSION_DATA,GET_API_DEF_DATA,SET_TAB} from './constant';


export default function storeCases(state = {overview_data:"",feature_data: [],version_data:[],apidef_data:{},tab:'overview'}, action) {
  switch (action.type) {
    case GET_OVERVIEW_DATA : 
      return {...state,  overview_data: action.payload};
    case GET_FEATURES_DATA: 
      return{...state, feature_data: action.payload};
    case GET_API_VERSION_DATA:
      return{...state, version_data: action.payload};
    case GET_API_DEF_DATA:
      return{...state, apidef_data: action.payload}; 
    case SET_TAB : 
      return{...state, tab: action.payload.name};  
    default:
    return state
  }
}


import { all, put, takeEvery, call, select } from 'redux-saga/effects';

import {
  GET_OVERVIEW,
  GET_OVERVIEW_DATA,
  GET_FEATURES,
  GET_FEATURES_DATA,
  GET_API_VERSION,
  GET_API_VERSION_DATA,
  GET_API_DEF,
  GET_API_DEF_DATA,
} from './constant';

import { getOverViewAPI, getFeaturesAPI, getVersions, getAPIDefination } from '../../../service/pdpAPI';

export function* getPDPOverviewAPI({ payload }) {
  const id = payload.id;
  try {
    let { data } = yield getOverViewAPI(id);
    if (data.statusType === 'SUCCESS') {
      yield put({ type: GET_OVERVIEW_DATA, payload: data?.response });
    } else {
      yield put({ type: GET_OVERVIEW_DATA, payload: '' });
    }
  } catch {
    yield put({ type: 'NETWORK ERROR' });
  }
}
export function* getPDPFeatureAPI({ payload }) {
  const id = payload.id;
  try {
    let { data } = yield getFeaturesAPI(id);

    if (data.statusType === 'SUCCESS') {
      yield put({ type: GET_FEATURES_DATA, payload: data?.response });
    } else {
      yield put({ type: GET_FEATURES_DATA, payload: [] });
    }
  } catch {
    yield put({ type: 'NETWORK ERROR' });
  }
}
export function* getPDPVersions({ payload }) {
  const id = payload.id;
  try {
    let { data } = yield getVersions(id);
    if (data.statusType === 'SUCCESS') {
      yield put({ type: GET_API_VERSION_DATA, payload: data?.response });
    } else {
      yield put({ type: GET_API_VERSION_DATA, payload: [] });
    }
  } catch {
    yield put({ type: 'NETWORK ERROR' });
  }
}
export function* getPDPapiDefination({ payload }) {
  const id = payload.id;
  try {
    let { data } = yield getAPIDefination(id, payload.token);
    if (data.statusType === 'SUCCESS') {
      yield put({ type: GET_API_DEF_DATA, payload: data?.response });
    } else {
      yield put({ type: GET_API_DEF_DATA, payload: [] });
    }
  } catch (error) {
    const token = localStorage.getItem('token');
    if ('Unauthorized' === error?.response?.data?.error && token) {
      localStorage.setItem('userLogin', 'NO');
    }
    yield put({ type: 'NETWORK ERROR' });
  }
}

export default function* watchAll() {
  yield all([
    takeEvery(GET_OVERVIEW, getPDPOverviewAPI),
    takeEvery(GET_FEATURES, getPDPFeatureAPI),
    takeEvery(GET_API_VERSION, getPDPVersions),
    takeEvery(GET_API_DEF, getPDPapiDefination),
  ]);
}

import { all, takeEvery, put } from 'redux-saga/effects'

import { FETCH_SUBSCRIPTION, FETCH_SUBSCRIPTION_SUCCESS, FETCH_SUBSCRIPTION_FAIL,
        ACCEPT_SUBSCRIPTION, ACCEPT_SUBSCRIPTION_SUCCESS, ACCEPT_SUBSCRIPTION_FAIL,
        DECLINE_SUBSCRIPTION, DECLINE_SUBSCRIPTION_SUCCESS, DECLINE_SUBSCRIPTION_FAIL
} from './constant';
import { get_subscription, accept_subscription, decline_subscription } from './apis';

export function* fetchSubscriptionAsync({payload}) {
    try {
        const token = localStorage.getItem("adminToken");
        let {data} = yield get_subscription(payload,token);
        if(data.statusType!='SUCCESS'){
            yield put({'type': FETCH_SUBSCRIPTION_FAIL, data: data?.message})
        } else {
            yield  put({'type':FETCH_SUBSCRIPTION_SUCCESS, data});
        }
    }  catch(err) {
        yield put({'type':'NETWORK ERROR'})
        if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
            localStorage.setItem("AdminAccess","No")
            window.location.href=`${window.location.origin}/admins`

        }
    }    
}



export function* acceptSubscriptionAsync(payload) {
    try {
        const token = localStorage.getItem("adminToken");
        let {data} = yield accept_subscription(payload,token);
        if(data.statusType!='SUCCESS'){
            yield put({'type': ACCEPT_SUBSCRIPTION_FAIL, data: data?.message})
        } else {
            yield  put({'type':ACCEPT_SUBSCRIPTION_SUCCESS, data});
        }
    }  catch(err) {
        yield put({'type':'NETWORK ERROR'})
        if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
            localStorage.setItem("AdminAccess","No")
            window.location.href=`${window.location.origin}/admins`

        }
    }    
}



export function* declineSubscriptionAsync(payload) {
    try {
        const token = localStorage.getItem("adminToken");
        let {data} = yield decline_subscription(payload,token);
        if(data.statusType!='SUCCESS'){
            yield put({'type': DECLINE_SUBSCRIPTION_FAIL, data: data?.message})
        } else {
            yield  put({'type':DECLINE_SUBSCRIPTION_SUCCESS, data});
        }
    }  catch(err) {
        if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
            localStorage.setItem("AdminAccess","No")
            window.location.href=`${window.location.origin}/admins`

        }
        yield put({'type':'NETWORK ERROR'})
    }    
}


export default function* watchAll() {
    yield all([
        takeEvery(FETCH_SUBSCRIPTION, fetchSubscriptionAsync),
        takeEvery(ACCEPT_SUBSCRIPTION, acceptSubscriptionAsync),
        takeEvery(DECLINE_SUBSCRIPTION, declineSubscriptionAsync),
    ])
    
}
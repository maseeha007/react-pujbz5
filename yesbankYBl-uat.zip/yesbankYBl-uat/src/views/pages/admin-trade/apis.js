import axios from 'axios';
import { APIMiddLEWAREURL } from '../../../env';

export const get_trade = (payload, token) => {
  const config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  return axios.get(`${window.yblDomain}` + '/admin/yesTrade?pageSize=' + payload.pageSize + '&pageNumber=' + payload.pageNumber, config);
};

// export const decline_lead = ({ payload }, token) => {
//   const config = {
//     headers: {
//       'Content-Type': 'application/json',
//       Authorization: `Bearer ${token}`,
//     },
//   };
//   return axios.put(APIMiddLEWAREURL + `/admin/actions?entityId=${payload}&actionFor=CA LEAD&actionType=REJECTED`, {}, config);
// };

// export const accept_lead = ({ payload }, token) => {
//   const config = {
//     headers: {
//       'Content-Type': 'application/json',
//       Authorization: `Bearer ${token}`,
//     },
//   };
//   return axios.put(APIMiddLEWAREURL + `/admin/actions?entityId=${payload}&actionFor=CA LEAD&actionType=APPROVED`, {}, config);
// };

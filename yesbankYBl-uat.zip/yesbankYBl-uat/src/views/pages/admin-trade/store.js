import { FETCH_TRADE_FAIL, FETCH_TRADE_SUCCESS, ACCEPT_TRADE_FAIL, ACCEPT_TRADE_SUCCESS, DECLINE_TRADE_SUCCESS, DECLINE_TRADE_FAIL } from './constant';


export default function storeCases(state = {}, action) {
  console.log('pkpk', action)
  switch (action.type) {
    case FETCH_TRADE_FAIL:
      return { ...state, error_msg: action.data.response }
    case FETCH_TRADE_SUCCESS:
      return { ...state, tradeList: action.data.response, subdata: action.data.response.totalPages, error_msg: null }
    case ACCEPT_TRADE_FAIL:
      return { ...state, error_msg: "Unable to Update, Some Server Error Occurred", success_msg: null }
    case ACCEPT_TRADE_SUCCESS:
      return { ...state, success_msg: "Accepted Successfully with ID: "+action.data.response, error_msg: null }
      case DECLINE_TRADE_FAIL:
      return { ...state, error_msg: "Unable to Update, Some Server Error Occurred", success_msg: null }
    case DECLINE_TRADE_SUCCESS:
      return { ...state, success_msg: "Declined Successfully with ID: "+action.data.response, error_msg: null }

    default:
      return state
  }
}


import axios from 'axios';
import { APIMiddLEWAREURL } from '../../../env';

export const get_subscription = (payload, token) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  return axios.get(
    `${window.yblDomain}` +
      '/admin/subscriptions?subscriptionType=CANCEL&subscriptionStatus=' +
      payload.type +
      '&pageSize=' +
      payload.pageSize +
      '&pageNumber=' +
      payload.pageNumber,
    config
  );
};

export const decline_subscription = ({ payload }, token) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  return axios.post(`${window.yblDomain}` + `/admin/actions?entityId=${payload}&actionFor=CANCEL%20SUBSCRIPTION&actionType=REJECTED`, {}, config);
};

export const accept_subscription = ({ payload }, token) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  return axios.post(`${window.yblDomain}` + `/admin/actions?entityId=${payload}&actionFor=CANCEL%20SUBSCRIPTION&actionType=APPROVED`, {}, config);
};

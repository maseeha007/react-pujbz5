import { PARTNER_FETCH_SUBSCRIPTION, PARTNER_ACCEPT_SUBSCRIPTION, PARTNER_DECLINE_SUBSCRIPTION, DOWNLOAD_PARTNER_RECORDS } from './constant';

export const get_subscriptions = (payload) => ({
  type: PARTNER_FETCH_SUBSCRIPTION,
  payload: payload,
});

export const accept_subscription = (payload) => ({
  type: PARTNER_ACCEPT_SUBSCRIPTION,
  payload: payload,
});

export const decline_subscription = (payload) => ({
  type: PARTNER_DECLINE_SUBSCRIPTION,
  payload: payload,
});

export const downloadPartnerSubAction = (payload) => ({
  type: DOWNLOAD_PARTNER_RECORDS,
  payload: payload,
});

import { all, takeEvery, put } from 'redux-saga/effects';
import {
  FETCH_LEAD,
  FETCH_LEAD_SUCCESS,
  FETCH_LEAD_FAIL,
  ACCEPT_LEAD,
  ACCEPT_LEAD_FAIL,
  ACCEPT_LEAD_SUCCESS,
  DECLINE_LEAD,
  DECLINE_LEAD_SUCCESS,
  DECLINE_LEAD_FAIL,
} from './constant';
import { get_lead } from './apis';

export function* fetchLEADAsync({ payload }) {
  try {
    const token = localStorage.getItem('adminToken');
    let { data } = yield get_lead(payload, token);
    if (data.statusType != 'SUCCESS') {
      yield put({ type: FETCH_LEAD_FAIL, data });
    } else {
      yield put({ type: FETCH_LEAD_SUCCESS, data });
    }
  } catch (err) {
    if (err?.response?.data?.error === 'Unauthorized' || err.response.status === 401) {
      localStorage.setItem('AdminAccess', 'No');
      window.location.href = `${window.location.origin}/admins`;
    }
    yield put({ type: 'NETWORK ERROR' });
  }
}

// export function* acceptLeadAsync(payload) {
//     try {
//         const token = localStorage.getItem("adminToken");
//         let { data } = yield accept_lead(payload,token);
//         console.log(data,'pkpk')
//         if (data.statusType != 'SUCCESS') {
//             yield put({ 'type': ACCEPT_LEAD_FAIL, data: data?.message })
//         } else {
//             yield put({ 'type': ACCEPT_LEAD_SUCCESS, data });
//         }
//     } catch(err) {
//         if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
//             localStorage.setItem("AdminAccess","No")
//             window.location.href=`${window.location.origin}/admins`

//         }
//         yield put({ 'type': 'NETWORK ERROR' })
//     }
// }

// export function* declineLeadAsync(payload) {
//     try {
//         const token = localStorage.getItem("adminToken");
//         let { data } = yield decline_lead(payload,token);
//         if (data.statusType != 'SUCCESS') {
//             yield put({ 'type': DECLINE_LEAD_FAIL, data: data?.message })
//         } else {
//             yield put({ 'type': DECLINE_LEAD_SUCCESS, data });
//         }
//     } catch (err){
//         if (err?.response?.data?.error==="Unauthorized" || err.response.status ===401) {
//             localStorage.setItem("AdminAccess","No")
//             window.location.href=`${window.location.origin}/admins`

//         }
//         yield put({ 'type': 'NETWORK ERROR' })
//     }
// }

export default function* watchAll() {
  yield all([
    takeEvery(FETCH_LEAD, fetchLEADAsync),
    // takeEvery(ACCEPT_LEAD, acceptLeadAsync),
    // takeEvery(DECLINE_LEAD, declineLeadAsync),
  ]);
}

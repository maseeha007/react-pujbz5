import React from 'react';
import './style.scss';

const Offers = (props) => {
  console.log('offer inside data========>', props);
  return (
    <>
      {props.offers && props.offers.trim().length > 0 && (
        <div className="offer-section">
          <div className="title">Special Offers For YESBANK Customers.</div>
          <div className="paragraph">
            <div className="offer" dangerouslySetInnerHTML={{ __html: props.offers }}></div>
          </div>
        </div>
      )}
    </>
  );
};

export default Offers;

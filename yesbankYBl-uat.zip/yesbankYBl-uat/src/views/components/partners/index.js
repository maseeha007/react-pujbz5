import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Tabs, Tab, Accordion, Card, Button, Modal, Toast, Spinner, Alert, Form, Badge } from 'react-bootstrap';
import Radio from '../../components/forms/radio';

import { scroller } from 'react-scroll';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';

import { updatePartner } from '../partnerProducts/action';
import { getAccountData } from '../account/actions';
import {
  checkSubscribe,
  sentEmailForNonCA,
  verifyCa,
  sendOtpCAUser,
  verifyOtp,
  sendOtpLoaderAction,
  setError,
  subscribeAction,
  getallpartners,
  resetmodaledata,
} from './action';
import { loginModalStatus } from '../../layout/header/action';
import Input from '../forms/input';
import Login from '../login/index';
import { connect } from 'react-redux';
import { onLoadOfProductORPartnerDetail, onSubscribeBtnClick, globalClickEvent } from '../../../analytics';
import Offers from '../offers';
import PhoneNumber from '../../components/forms/phoneNumber';
import Otp from '../../components/forms/otp';
import './style.scss';

class partnerDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openPopup: false,
      details: {},
      error: {},
      showlogin: false,
      id: '',
      name: '',
      solution: '',
      key: '',
      openToast: false,
      showSubscribe: false,
      showVideo: false,
      taosterShown: false,
      showfailOpen: false,
      showSubscribe_error: false,
      subscribedDone: false,
      statusUpdated: false,
      checkUser: '',
      introduction: null,
      features: null,
      isCustIdVisible: true,
      otpVerified: false,
      otpDisabled: true,
      otpTime: 0,
      show: false,
      productName: '',
      productId: '',
      custidmutiplexpress:[]
    };
    this.timer = null;
    //this.demo = this.demo.bind(this);
    // this.handleModalOpensubscrib = handleModalOpensubscrib.bind(this);
  }
  parseQuery(queryString) {
    var query = {};
    var pairs = (queryString[0] === '?' ? queryString.substr(1) : queryString).split('&');
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i].split('=');
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || '');
    }
    return query;
  }

  componentDidUpdate(prevProp) {
    if (prevProp.accountValues.custId !== this.props?.accountValues.custId && this.props?.accountValues.custId) {

      let cutidval = this.props?.accountValues?.custId?.replace(/'/g, '"');
  let resultdata = JSON.parse(cutidval);
  debugger;
      this.setState({custidmutiplexpress:resultdata})
    }
    if (this.props.updateLogin == 1 && this.state.partnerUpdated !== true) {
      setTimeout(() => {
        this.setState({
          ...this.state,
          partnerUpdated: true,
          openPopup: false,
        });
      }, 2000);
    }

    if (this.props.issubscribed.statusCode == 200 && !this.state.taosterShown) {
      if (this.props.issubscribed.statusType == 'Not Updated') {
        this.setState({ ...this.state, openToast: true, taosterShown: true });
      } else if (this.props.issubscribed.statusType == 'SUCCESS') {
        this.setState({ ...this.state, showSubscribe: true, taosterShown: true, otpDisabled: false });
      } else if (this.props.issubscribed.statusCode == 500) {
        this.setState({ ...this.state, showSubscribe_error: true });
      }
    }
    if (prevProp.otpStatus !== this.props.otpStatus && this.props.otpStatus) {
      this.setState({ ...this.state, otpTime: 0, otpDisabled: true });
      clearInterval(this.timer);
    }
    // if (prevProp.introduction !== this.props.introduction) {
    //   this.setState({ introduction: this.props.introduction && this.props.introduction.map((a) => a.replace(/(<([^>]+)>)/gi, '')) });
    // }
    if (prevProp.features !== this.props.features) {
      const numsPerGroup = Math.ceil(this.props?.features.length / 3);
      const result = new Array(3).fill('').map((_, i) => this.props.features.slice(i * numsPerGroup, (i + 1) * numsPerGroup));
      this.setState({
        features: result,
      });
    }
    if (prevProp.isOtpSent !== this.props.isOtpSent && this.props.isOtpSent) {
      this.setState({ ...this.state, otpSent: true, otpDisabled: false, startTimer: true });
      this.timer = setInterval(() => {
        this.setState({ ...this.state, otpTime: this.state.otpTime ? this.state.otpTime - 1 : 60 });
      }, 1000);
      setTimeout(() => {
        if (this.timer !== null) {
          this.setState({ ...this.state, otpDisabled: false, otpTime: 0, startTimer: false, OtpText: 'Resend OTP' });
        }
        clearInterval(this.timer);
      }, 60000);
    }
  }
  componentDidMount() {
    this.props.getAccountData();
    //var qs = this.parseQuery(window.location.search);
    this.props.getallpartners();
    console.log('Maseeha' + this.props.products);
  }
  saveValue(name, e) {
    let value = e.target.value;
    if (name === 'solname' || name === 'desc') {
      value = e.target.value.replace(/[^a-z0-9 ]/gi, '');
    }
    this.setState({
      ...this.state,
      details: { ...this.state.details, [name]: value },
    });
  }

  handleLogin() {
    let flag = false;
    let errObj = {};
    let dataObj = {};

    if (!this.state.details.solname) {
      errObj['solname'] = 'Please Enter Product/Solution';
      document.getElementById('solname').focus();
      flag = true;
    } else {
      dataObj['solname'] = this.state.details.solname;
    }

    if (!this.state.details.desc) {
      errObj['desc'] = 'Please Enter description';
      if (!flag) {
        document.getElementById('desc').focus();
      }

      flag = true;
    } else {
      dataObj['desc'] = this.state.details.desc;
    }
    if (flag) {
      this.setState({ ...this.state, error: { ...errObj } });
      return;
    } else {
      let userObj = {
        custId: this.props.accountValues.custId,
        firstName: this.props.accountValues.firstName,
        lastName: this.props.accountValues.lastName,
        emailId: this.props.accountValues.emailId,
        isEnabled: this.props.accountValues.isEnabled,
        mobile: this.props.accountValues.mobile,
        organisation: this.props.accountValues.organisation,
        partnerOptIn: this.props.accountValues.partnerOptIn,
        solutionName: dataObj.solname,
        productDescription: dataObj.desc,
        leadgenStatus: this.props.accountValues.leadgenStatus,
      };
      this.props.updatePartner(userObj);
      setTimeout(() => {
        this.setState({ ...this.state, openPopup: false });
        window.location.reload();
      }, 5000);
    }
  }

  handleClose = () => {
    this.setState({ ...this.state, error: {}, openPopup: false });
    // window.location.reload();
  };

  handleModalclose = () => {
    this.setState({ show: false
     // ,isCustIdVisible:true,disabledVerify :false,verify_user_state:'' 
    });
    window.location.reload();
   debugger;
    this.props.resetmodaledata();
  };
  handleOpen() {
    if (!localStorage.token) {
      globalClickEvent(`button clicked login`);
      this.props.openModal();
    } else {
      globalClickEvent(`button clicked login`);
      this.setState({ ...this.state, openPopup: true });
    }
  }
  handleSubscrption() {
    let isError = false;
    this.setState({ ...this.state, isCustIdError: false, custErrorMsg: '' });
    // debugger;
    if (!localStorage.token) {
      globalClickEvent(`button clicked login`);
      this.props.openModal();
    } else {
      let payload = {
        name: this.state.name,
        productId: this.state.productId,
      };
      if (this.state.isCustIdVisible) {
        if (this.props?.accountValues?.custId || this.state?.custId || this.state.caNumber) {
          payload.custId = this.props?.accountValues?.custId ? this.props?.accountValues?.custId : this.state.custId;
        }
        if (this.state.caNumber) {
          payload.custId = this.state.caNumber;
        }
        if (!payload.custId) {
          isError = true;
          this.setState({ ...this.state, isCustIdError: true, custErrorMsg: 'Please Enter Valid Cust Id' });
        }
        if (payload.custId && !this.props?.verify_user_state) {
          isError = true;
          this.setState({ ...this.state, isCustIdError: true, custErrorMsg: 'Please Verify Cust Id' });
        }
        if (this.props.otpStatus != 'success') {
          isError = true;
          this.props.setError('Please varify cust Id with OTP');
        }
      }
      if (!isError) {
        debugger;
        this.props.setError(undefined);
        this.props.checkSubscribe(payload);

        if (Object.keys(this.props?.accountValues).length) {
          const payload = {
            firstName: this.props?.accountValues?.firstName,
            lastName: this.props?.accountValues?.lastName,
            organisation: this.props?.accountValues?.organisation,
            email: this.props?.accountValues?.emailId,
            mobile: this.props?.accountValues?.mobile,
            custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : 'N/A',
            productName: this.state?.name ? this.state.name : '',
          };
          this.props.sentEmailForNonCA(payload);
        }
      }

      const analyticspayload = {
        productName: null,
        productType: 'partner product',
        partnerName: this.state.name,
        solutionName: this.state?.solution?.replace('~', '&'),
      };
      onSubscribeBtnClick(analyticspayload);
      if (Object.keys(this.props?.accountValues).length) {
        const payload = {
          firstName: this.props?.accountValues?.firstName,
          lastName: this.props?.accountValues?.lastName,
          organisation: this.props?.accountValues?.organisation,
          email: this.props?.accountValues?.emailId,
          mobile: this.props?.accountValues?.mobile,
          custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : 'N/A',
          productName: this.state?.name ? this.state.name : '',
        };
        this.props.sentEmailForNonCA(payload);
      }
    }
  }
  handleCloseSubscribe = () => {
    this.setState({ ...this.state, showSubscribe: false });
  };
  handleOkSubscribe = () => {
    this.setState({ ...this.state, showSubscribe: false });
    let payload = {
      name: this.state.name,
      productId: this.state.productId,
    };
    this.props.checkSubscribe(payload);
  };
  handleOpenSubscribe() {
    if (!this.props.issubscribed.statusCode && !this.state.subscribedDone) {
      this.setState({ ...this.state, showSubscribe: true });
    } else if (this.props.issubscribed.statusCode == 200 || this.state.subscribedDone) {
      if (this.props.issubscribed.statusType == 'Not Updated') {
        this.setState({ ...this.state, openToast: true, subscribedDone: true });
        setTimeout(() => {
          window.open(this.props.OverviewValues.redirectURL);
        }, 2000);
      } else if (this.props.issubscribed.statusCode == 500) {
        this.setState({ ...this.state, showSubscribe_error: true });
      }
    }
  }
  handleCloseLogin = () => {
    this.setState({ ...this.state, showlogin: false });
  };
  handleToastOpen() {
    this.setState({ ...this.state, taosterShown: false }, () => {
      this.closeDisclaimer();
      let payload = {
        name: this.state.name,
        productId: this.state.productId,
      };
      this.props.checkSubscribe(payload);
    });
  }
  handlefailToastOpen() {
    if (Object.keys(this.props?.accountValues).length) {
      const payload = {
        firstName: this.props?.accountValues?.firstName,
        lastName: this.props?.accountValues?.lastName,
        organisation: this.props?.accountValues?.organisation,
        email: this.props?.accountValues?.emailId,
        mobile: this.props?.accountValues?.mobile,
        custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : 'N/A',
        productName: this.state?.name ? this.state.name : '',
      };
      this.props.sentEmailForNonCA(payload);
    }
    this.setState({ ...this.state, showfailOpen: true });
  }
  handlefailToastClose() {
    this.setState({ ...this.state, showfailOpen: false });
  }
  handleToastClose() {
    this.setState({ ...this.state, openToast: false });
  }
  handleOpenVideo() {
    this.setState({ ...this.state, showVideo: true });
  }
  handleCloseVideo() {
    this.setState({ ...this.state, showVideo: false });
  }
  moveTo = (event) => {
    scroller.scrollTo(event);
  };
  handleAccord = (e) => {
    this.setState({ ...this.state, key: e });
  };

  modalForSubscrption = (data) => {
    debugger;
    if (!localStorage.token) {
      globalClickEvent(`button clicked login`);

      this.props.openModal();
    } else {
      this.setState({ show: !this.state.show, productId: data.productId, productName: data.productName });
    }
    // else {
    //   // check digital on board flag  if true  do thid
    //   if (this.props.digiOnboard) {
    //     this.setState({ ...this.state, modalAccount: true, disabledVerify: false, caNumber: '' });

    //     this.setState({show:!this.state.show,})

    //   } else {
    //     debugger;
    //     this.setState({partnerid:partid,partnername:partname})
    //     console.log("maseehaname" ,this.state.partname,"maseehaid", this.state.partnerid)
    //     const reqPayload = {
    //       custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : 'N/A',
    //       productName: this.props.name?this.props.name:'',
    //       //partname ? partname:'',
    //       //this.state.name : '',
    //       productId: this.props.productId?this.props.productId:''
    //       //partid,
    //       //this.props.productId,
    //     };
    //     this.props.setError(undefined);
    //     this.props.checkSubscribe(reqPayload);
    //    // window.open(this.props.OverviewValues.redirectURL);
    //    this.setState({show:!this.state.show})
    //     window.blur();

    //     if (Object.keys(this.props?.accountValues).length) {
    //       const payload = {
    //         firstName: this.props?.accountValues?.firstName,
    //         lastName: this.props?.accountValues?.lastName,
    //         organisation: this.props?.accountValues?.organisation,
    //         email: this.props?.accountValues?.emailId,
    //         mobile: this.props?.accountValues?.mobile,
    //         custId: this.props?.accountValues?.custId ? this.props?.accountValues?.custId : 'N/A',
    //         productName: this.state?.name ? this.state.name : '',
    //       };
    //       this.props.sentEmailForNonCA(payload);
    //     }
    //   }
    //   globalClickEvent(`subscription button clicked`);
    // }
  };
  // handleModalClose() {
  //   this.setState({ ...this.state, modalAccount: false });
  // }

  saveCaAccount(e) {
    this.setState({ ...this.state, caNumber: e.target.value });
  }

  makeVerify() {
     debugger;
    if (this.state.caNumber || this.state?.custidmutiplexpress) {
      this.setState({ ...this.state, disabledVerify: true, checkUser: 'SET', disclaimer: false, userVerified: false, useNew: true }, () => {
        this.props.verify_user(this.state.caNumber ? this.state.caNumber :JSON.stringify(this.state?.custidmutiplexpress[0]) );
      });
    } else {
      this.setState({ ...this.state, userVerified: false, disabledVerify: false, error: { ...this.state.error, caError: 'Please Enter Customer ID' } });
    }
  }

  openDisclaimer() {
    this.setState({ ...this.state, disclaimer: true });
  }

  closeDisclaimer() {
    this.setState({ ...this.state, disclaimer: false });
  }

  showCurrentAccount() {
    this.setState({ ...this.state, isCustIdVisible: true });
  }
  hideCurrentAccount() {
    this.setState({ ...this.state, isCustIdVisible: false });
  }
  validateMobileNumber() {
    debugger;
    this.props.sendOtpLoaderAction(true);

    if (this.props?.verified_user?.mobile?.length > 0) {
      debugger;
      this.props.sendOtpCAUser(this.props?.verified_user?.custId);
    }
  }

  verifyClickNow() {
    // debugger;
    if (this.state?.details?.otp?.length === 6) {
      this.props.verifyOtp(this.state.details.otp);
      this.setState({ ...this.state, otpSent: true });
    } else {
      this.setState({ ...this.state, error: { otp: true }, otp_status: 'fail', otp_messgae: 'Please enter valid OTP' });
    }
  }
  debugger;
  render() {
    return (
      <>
        <Header title="yesxpress onboarding" />

        <div className="partnerWraper">
          <section id="support">
            <div className="banner-container">
              <h2 className="banner-heading">yesxpress onboarding</h2>
            </div>
          </section>
          <div className="container">
            <div className="parnter-heading">Digitally link your YES BANK business current account to our Partner application</div>
            <div className="table-responsive">
              <table className="table  table-striped">
                {/* <thead className="">
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Name</th>
                    <th scope="col">Logo</th>
                    <th scope="col">Description</th>
                    <th>{localStorage.getItem('role') !== 'PSM' && 'Subscribe'}</th>
                  </tr>
                </thead> */}
                <tbody>
                  {this.props.products.map((item, i) => {
                    return (
                      <>
                        {item.products?.map((patnerdata) => {
                          if (patnerdata?.digiOnboard) {
                            return (
                              <tr>
                                <td>{patnerdata.productName}</td>
                                <td>
                                  <img
                                    className="partnerlogo"
                                    src={'/assets/img/' + String(patnerdata.productName).toLowerCase().replace(/\s/g, '-') + '-logo.svg'}
                                    alt=""
                                  ></img>
                                </td>
                                <td>
                                  <p className="">{patnerdata.description}</p>
                                </td>

                                <td>
                                  {localStorage.getItem('role') !== 'PSM' && (
                                    <Button className="submit-link pointer btn-default" onClick={this.modalForSubscrption.bind(this, patnerdata)}>
                                      Link Account
                                    </Button>
                                  )}
                                </td>
                              </tr>
                            );
                          }
                        })}
                      </>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <Modal className={'partnersModal'} show={this.state.show} onHide={() => this.handleModal()}>
            <Modal.Header>
              Subscription ({this.state.productName})
              <button type="button" class="close">
                <span aria-hidden="true">
                  <img alt="icon" className="close-icon" src="/assets/icons/login-close.svg" onClick={this.handleModalclose} />
                </span>
              </button>
            </Modal.Header>
            <Modal.Body className="mt-3 boxform">
              {this.props.issubscribed.statusCode == 200 && (
                <Alert variant="success" className="mb-4">
                  Thank you for subscribing to {this.state.productName}. You will receive an email on your registered email ID to complete the onboarding process for
                  your bank account. Please follow the link in the email to complete the setup for your bank account
                </Alert>
              )}
              {this.props.issubscribed.statusCode != 200 && (
                <>
                  {this.state.isCustIdVisible && (
                    <>
                      <div className="col-md-12 m-t-40 m-bottom-35">
                        {/* {this.state.error.caError ? <p className="text-danger no-margin">{this.state.error.caError}</p> : null} */}

                        { this.state?.custidmutiplexpress.length>1 ?<><Form.Label>
                      CustID<span className="text-danger">*</span>
                  </Form.Label>
                      <Form.Control   onChange={this.saveCaAccount.bind(this)}   name="custID" as="select" className="custid"  value={this.state.caNumber ? this.state.caNumber : this.state?.custidmutiplexpress[0]}
                        defaultValue={this.state?.custidmutiplexpress[0] ? this.state?.custidmutiplexpress[0] : ''}
                        disabled={this.props?.verify_user_state == 'success' && this.state.isCustIdVisible }
                         
                         >
                     
                       {  this.state?.custidmutiplexpress?.map((data, index) => (
                      <option selected={index==0} value={data} >{data}</option>
                       ))
                       } 
                      </Form.Control></>:''}

                      { this.state?.custidmutiplexpress.length< 2? <Input
                        label={'CustID'}
                        onChange={this.saveCaAccount.bind(this)}
                        required
                        name="custID"
                        // value={this.state.caNumber}
                        value={this.state.caNumber ? this.state.caNumber : this.state?.custidmutiplexpress[0]}
                        defaultValue={this.state?.custidmutiplexpress ? this.state?.custidmutiplexpress[0] : ''}
                        disabled={this.state?.custidmutiplexpress[0] ? true : false}
                      />:''}
                        {/* )} */}
                        {this.props?.verify_user_state == 'success' && this.state.isCustIdVisible && (
                          <span className="success">{this.props?.verify_messgae}</span>
                        )}
                        {this.props?.verify_user_state == 'fail' && this.state.isCustIdVisible && <span className="error">{this.props?.verify_messgae}</span>}
                        {this.state?.isCustIdError &&
                          this.state.isCustIdVisible &&
                          this.props?.verify_user_state != 'fail' &&
                          this.props?.verify_user_state != 'success' && <span className="error">{this.state.custErrorMsg}</span>}

                        <Button
                          onClick={this.makeVerify.bind(this)}
                          className={`verify-btn pull-right ${this.state.disabledVerify ? 'disabled' : ''}`}
                          variant="link"
                        >
                          Verify
                          {this.props.caLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
                        </Button>
                      </div>

                      <div className="col-md-12 m-t-40 m-bottom-20 display-flex">
                        <Form.Control as="select" disabled={true} value={'91'} className="phone-code">
                          <option value={'91'}>+{'91'}</option>;
                        </Form.Control>
                        <PhoneNumber
                          id="phoneno"
                          showLoader={this.props.sendOtpLoader}
                          // otpDisabled={this.state.otpDisabled}
                          otpDisabled={false}
                          timeStr={this.state.otpTime}
                          otpText={this.state.OtpText}
                          label={'Mobile Number'}
                          value={this.props?.verified_user?.mobile}
                          required
                          name="mobile"
                          error={this.state.error.mobile}
                          disableSendOtpLink={this.props?.verified_user?.mobile?.length > 0}
                          onChange={this.saveValue.bind(this, 'mobile')}
                          otpClick={this.validateMobileNumber.bind(this)}
                          disabled={true}
                        />
                      </div>

                      <div className="col-md-12 m-t-40 m-bottom-20">
                        <Otp
                          id="otp"
                          label={'Otp'}
                          showLoader={this.props?.verifyOtpLoader}
                          otpDisabled={this.props.otpStatus == 'success'}
                          verifyState={this.props.otpStatus}
                          verifyMsg={this.props.otp_success_msg}
                          verifyClick={this.verifyClickNow.bind(this)}
                          error={this.state.error.otp}
                          onChange={this.saveValue.bind(this, 'otp')}
                          disabled={!this.state.otpSent || this.props.otpStatus == 'success'}
                          required
                          name="otp"
                          value={this.state.otp}
                        />
                        {this.state.otp_status == 'fail' && !this.props.otpStatus && <span className="error">{this.state.otp_messgae}</span>}
                      </div>
                      <div className="col-md-12 m-t-40 m-bottom-20">
                        <Input
                          label={'Name'}
                          name="Name"
                          value={`${this.props?.verified_user?.firstName ? this.props?.verified_user?.firstName : ''} 
                    ${this.props?.verified_user?.lastName ? this.props?.verified_user?.lastName : ''}`}
                          defaultValue={`${this.props?.verified_user?.firstName ? this.props?.verified_user?.firstName : ''} 
                    ${this.props?.verified_user?.lastName ? this.props?.verified_user?.lastName : ''}`}
                          disabled={true}
                        />
                      </div>
                      <div className="col-md-12 m-t-40 m-bottom-20">
                        <Input
                          label={'Email'}
                          name="email"
                          value={`${this.props?.verified_user?.emailId ? this.props?.verified_user?.emailId : ' '}`}
                          defaultValue={`${this.props?.verified_user?.emailId ? this.props?.verified_user?.emailId : ' '}`}
                          disabled={true}
                        />
                      </div>
                    </>
                  )}
                </>
              )}

              <div className="col-md-12 m-t-40 m-bottom-20">{this.props.partnerError && <Alert variant="danger">{this.props.partnerError}</Alert>}</div>
              {this.props.issubscribed.statusCode != 200 && localStorage.getItem('role') !== 'PSM' && (
                <div className="col-md-12 m-t-40 m-bottom-20">
                  <Button className="submit-btn pull-right" variant="default" onClick={this.handleSubscrption.bind(this)}>
                    Subscribe {this.props.parterLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true"></Spinner>}
                  </Button>
                </div>
              )}
            </Modal.Body>
          </Modal>
        </div>
        <Footer />
      </>
    );
  }
}
// overviewFeatures: state.partnersReducer.overview.overviewFeatures,

const mapStateToProps = (state) => ({
  isSubscribed: state.partnersReducer.isSubscribed,
  accountValues: state.accountReducer.accountDetails,
  partnerProducts: state.partnerReducer.Partnerproducts,
  updateLogin: state.partnerReducer.updatePartner,
  error_update: state.partnerReducer.error_update,
  OverviewValues: state.partnersReducer.overview,
  features: state.partnersReducer.features,
  issubscribed: state.partnersReducer.checksubscribe,
  verify_messgae: state.partnersReducer.verified_message,
  verified_user: state.partnersReducer.verified_user,
  random: state.partnersReducer.verified_user,
  verify_user_state: state.partnersReducer.verify_user_state,
  introduction: state.partnersReducer.overview.introduction,
  overviewFeatures: state.partnersReducer.overview.overviewFeatures,
  partnerError: state.partnersReducer.error,
  parterLoader: state.partnersReducer.parterLoader,
  caLoader: state.partnersReducer.caLoader,
  offer: state.partnersReducer.overview.offer,
  sendOtpLoader: state.partnersReducer.sendOtpLoader,
  isOtpSent: state.partnersReducer.sendOTPStatus,
  otpStatus: state.partnersReducer.otp_verify_state,
  otp_success_msg: state.partnersReducer.otp_text_msg,
  isSubscribed: state.partnersReducer.isSubscribed,
  digiOnboard: state.partnersReducer.overview.digiOnboard,
  productId: state.partnersReducer.overview.productId,
  products: state.partnersReducer.products,
  searchParams: state.searchReducer.results,
  error: state.solutionsReducer.error,
});
const mapDispatchToProps = (dispatch) => {
  return {
    getAccountData: () => dispatch(getAccountData()),
    updatePartner: (obj) => dispatch(updatePartner(obj)),
    checkSubscribe: (payload) => dispatch(checkSubscribe(payload)),
    openModal: () => dispatch(loginModalStatus(true)),
    sentEmailForNonCA: (payload) => dispatch(sentEmailForNonCA(payload)),
    verify_user: (payload) => dispatch(verifyCa(payload)),
    sendOtpCAUser: (custId) => dispatch(sendOtpCAUser(custId)),
    verifyOtp: (otp) => dispatch(verifyOtp(otp)),
    sendOtpLoaderAction: (flag) => dispatch(sendOtpLoaderAction(flag)),
    setError: (msg) => dispatch(setError(msg)),
    subscribeAction: (id, token) => dispatch(subscribeAction(id, token)),
    getallpartners: () => dispatch(getallpartners()),
    resetmodaledata: () => dispatch(resetmodaledata()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(partnerDetail);

import { data } from 'autoprefixer';
import {
  P_CHECK_SUBSCRIBE_SUCCESS,
  P_CHECK_SUBSCRIBE_FAILURE,
  P_VERIFY_CA_SUCCESS,
  P_VERIFY_CA_FAIL,
  P_PARTNER_LOADER,
  P_CA_LOADER,
  P_SEND_OTP_FORPARTENR_LOADER,
  P_SEND_OTP_SUCCESS,
  P_SEND_OTP_STATUS,
  P_VERIFY_OTP_LOADER,
  PS_VERIFY_OTP_STATUS,
  PS_VERIFY_OTP_SUCCESS,
  P_SET_SUBSCRIBE_DATA,
  P_GET_PRODUCTS_SUCCESS, P_GET_PRODUCTS_FAILURE,
  P_RESETSUBSCRIED_MODULE
} from './constant';

const initialState = {
  overview: [],
  features: [],
  error: null,
  checksubscribe: [],
  sendOtpLoader: false,
  products: [],
  error: null,
};

const partnerProductReducer = (state = initialState, action) => {
  switch (action.type) {
    case P_CHECK_SUBSCRIBE_SUCCESS:
      return { ...state, checksubscribe: action.data, error: null };
      case P_RESETSUBSCRIED_MODULE:
        return { ...state, checksubscribe: [], error: null };
    case P_CHECK_SUBSCRIBE_FAILURE:
      return {
        ...state,
        error: action.error_message,
      };

    case P_VERIFY_CA_SUCCESS:
      return { ...state, verify_user_state: 'success', verified_message: 'CustId verifed', verified_user: action.data, random: Math.random() };
    case P_VERIFY_CA_FAIL:
      return { ...state, verify_user_state: 'fail', verified_message: action.data };
    case P_PARTNER_LOADER:
      return { ...state, parterLoader: action.data };
    case P_CA_LOADER:
      return { ...state, caLoader: action.data };
    case P_SEND_OTP_FORPARTENR_LOADER:
      return { ...state, sendOtpLoader: action.data };
    case P_SEND_OTP_SUCCESS:
      return { ...state, send_otp_state: 'success', send_otp_data: action.data };
    case P_SEND_OTP_STATUS:
      return { ...state, sendOTPStatus: action.data };
    case P_VERIFY_OTP_LOADER:
      return { ...state, verifyotpLoder: action.data };
    case PS_VERIFY_OTP_STATUS:
      return { ...state, otp_verify_state: action.data };
    case PS_VERIFY_OTP_SUCCESS:
      return { ...state, otp_text_msg: action.data };
    case P_SET_SUBSCRIBE_DATA:
      return { ...state, isSubscribed: action.payload };
    default:
      return state;
      case P_GET_PRODUCTS_SUCCESS:
      return { ...state, products: action.data,error:null};
    case P_GET_PRODUCTS_FAILURE:
      return { ...state, error: action.error_message ? action.error_message  :'No Product available' };
    
  }
};

export default partnerProductReducer;

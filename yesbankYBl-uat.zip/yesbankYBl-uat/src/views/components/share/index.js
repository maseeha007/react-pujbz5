import React, { Component } from 'react';
import './style.scss';
import { Button, Modal, Spinner, Alert, InputGroup, FormControl } from 'react-bootstrap';

class Share extends Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
      textToCopy: window.location.href,
      copySuccess: 'Copy Link',
    };
  }
  componentDidMount() {}
  copyToClipboard = () => {
    this.setState({ copySuccess: 'Copied!' });
    debugger;
    navigator.clipboard.writeText(this.state.textToCopy);
  };
  handleClose = () => {
    this.setState({ ...this.state, error: {}, openPopup: false });
    // window.location.reload();
  };

  handleModalclose = () => {
    this.setState({ show: false });
    //this.props.resetmodaledata();
  };
  handleShare = () => {
    this.setState({ show: true });
  };
  render() {
    // const {
    //   url = String(window.location),
    //   title = "",
    //   //shareImage = "https://www.steadylearner.com/static/images/brand/prop-passer.png",
    //   size = "2.5rem",
    // } = this.props;

    // const ShareList = Passers({

    //   url,
    //   className: "network__share-button",
    // })({
    //   className: "network cursor-pointer hover transition--default",
    //   title: `Share ${String(this.state.tooltip)}`,
    // })("div");
    return (
      <>
        {/* <div className="sharewraper" onClick={this.handleShare.bind(this)}>
          <span target="_blank" data-title="Share by facebook" className="share-facebook sharelink">
            <i className="fa fa-facebook" aria-hidden="true"></i>
          </span>
          <span target="_blank" data-title="Share by twitter" className="share-twitter sharelink">
            <i className="fa fa-twitter" aria-hidden="true"></i>
          </span>
          <span target="_blank" data-title="Share by whatsapp" data-action="share/whatsapp/share" className="share-whatsapp sharelink">
            <i className="fa fa-whatsapp" aria-hidden="true"></i>
          </span>
          <span className="share-email sharelink" data-title="Share by Email">
            <i className="fa fa-envelope-o" aria-hidden="true"></i>
          </span>
          {/* <span target="_blank" className="share-link sharelink" data-title="Share on link">
            <i className="fa fa-link" aria-hidden="true"></i>
          </span> 
        </div> */}
        <button className="actionbutton" onClick={this.handleShare.bind(this)}>
          <i className="fa fa-share-alt" aria-hidden="true"></i>
        </button>
        <Modal className={'shareModal'} show={this.state.show} onHide={() => this.handleShare()}>
          <Modal.Header>
            <span className="heading">Share this page now to your contacts</span>
            <button type="button" class="close">
              <span aria-hidden="true">
                <img alt="icon" className="close-icon" src="/assets/icons/login-close.svg" onClick={this.handleModalclose} />
              </span>
            </button>
          </Modal.Header>
          <Modal.Body className="boxform">
            <h3>Link to share</h3>

            <FormControl disabled value={window.location.href} className="inputbox" aria-label="Dollar amount (with dot and two decimal places)" />
            <div className="col-md text-right">
              <Button title="copy to the clipboard " variant="primary" className="copybtn" onClick={this.copyToClipboard.bind()}>
                {this.state.copySuccess}
              </Button>{' '}
            </div>
            {/* <span className="boxline"></span>
            <div className="col-md">
              <h3>Share through other medium</h3>
              <div className="sharepopup">
                <a
                  target="_blank"
                  title="Share by facebook"
                  href={'//www.facebook.com/sharer.php?u=' + window.location.href}
                  className="share-facebook "
                  title="Share on Facebook"
                >
                  <i className="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a
                  target="_blank"
                  title="Share by twitter"
                  href={'//twitter.com/share?text=hii&amp;url=' + window.location.href}
                  className="share-twitter"
                  title="Tweet on Twitter"
                >
                  <i className="fa fa-twitter" aria-hidden="true"></i>
                </a>
                <a
                  target="_blank"
                  title="Share by whatsapp"
                  data-action="share/whatsapp/share"
                  href={'https://api.whatsapp.com/send?text=' + window.location.href}
                  className="share-whatsapp"
                >
                  <i className="fa fa-whatsapp" aria-hidden="true"></i>
                </a>
                <a className="share-email " href={'mailto:?subject=' + window.location.href} title="Share by Email">
                  <i className="fa fa-envelope-o" aria-hidden="true"></i>
                </a>
                {/* <a target="_blank" href={"//www.facebook.com/sharer.php?u=" + window.location.href} className="share-link" title="Share on link">
                <i className="fa fa-link" aria-hidden="true"></i>
              </a> */}
            {/* </div>
            </div>
            </div>  */}
          </Modal.Body>
        </Modal>
      </>
    );
  }
}

export default Share;

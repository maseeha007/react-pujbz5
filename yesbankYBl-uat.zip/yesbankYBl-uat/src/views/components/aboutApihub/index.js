import React, { Component } from 'react';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import './style.scss';
import { withRouter } from 'react-router';
import { getAccountData } from '../account/actions';
import { onLoadTrack, globalClickEvent } from '../../../analytics';

class Index extends Component {
  componentDidMount() {
    this.props.getAccountData();
    const payload = {
      pageName: 'yes connect|aboutus',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
  }

  goToAnotherAge = () => {
    globalClickEvent('button clicked on register');
    window.location.href = '/register';
  };
  render() {
    return (
      <>
        <Header />
        <section id="about">
          <div className="banner-container">
            <h2 className="banner-heading">
              <span>About YES CONNECT </span>{' '}
            </h2>
          </div>
          <div className="body-container">
            <div className="sub-container">
              <p className="text-content">
                Building on its vision to provide the best in class technology solutions and also the products in collaboration with its strategic partners and
                technology providers, YES BANK is pleased to present YES CONNECT – a unique platform to showcase our solutions to our valuable customers across
                sectors like SME, Fintech, NBFC, Accounting.{' '}
              </p>
              <p className="text-content">
                {' '}
                YES CONNECT is a one stop marketplace website offering curated cutting-edge tech based solutions customized to meet your unique business
                requirements. YES CONNECT also offers solutions by our partners which are powered by YES BANK.
              </p>
              <p className="text-content">
                The team will understand your requirements and curate comprehensive solutions from the pool of solutions available.
              </p>
              <p className="text-content">
                <a href="explore">Click here</a> to explore our solutions.
              </p>
              <p className="text-content">
                {' '}
                YES CONNECT acts as a bridge to get connected with myriad of solutions & offerings to help ease and scale your business and accelerate your
                business operations.Sign up with YES CONNECT to see and subscribe the various solutions by YES BANK.
              </p>
              {!localStorage.getItem('token') && (
                <p className="text-content">
                  {' '}
                  <a onClick={this.goToAnotherAge}>Click here</a> to Register now.
                </p>
              )}
            </div>
          </div>
          {!localStorage.getItem('token') && (
            <div className="pbanner-section">
              <div className="partner-section">
                <Link className="ptitle " to="/register">
                  Sign Up to view detailed technical specification & Subscribe
                </Link>
                <p className="p-descrption">
                  After Sign Up you will be able to subscribe to range of YES BANK and Partners Products. This will help you optimize your digital platform and
                  also offer better digital experience to your customers.
                </p>
                <Link
                  onClick={this.goToAnotherAge}
                  // to="/register"
                >
                  <Button className="submit-btn" variant="default">
                    Register Now
                  </Button>
                </Link>
              </div>
            </div>
          )}
        </section>
        <Footer />
      </>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    ...state,
  };
};

const mapDispatchToProps = (dispatch) => ({
  getAccountData: () => dispatch(getAccountData()),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));

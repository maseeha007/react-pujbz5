import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { useHistory } from 'react-router-dom';
import { useDispatch } from 'react-redux';

import './style.scss';

const Features = (props) => {
  const cardData = [
    {
      title: 'Heading 1',
      data: 'Initiating a bulk payment is easy. Add the PSD2 Payments solution into the configuration of your application.',
      img: 'assets/icons/online-payment.svg',
    },
    {
      title: 'Heading 2',
      data: 'Initiating a bulk payment is easy. Add the PSD2 Payments solution into the configuration of your application.',
      img: 'assets/icons/wallet.svg',
    },
    {
      title: 'Heading 3',
      data: 'Initiating a bulk payment is easy. Add the PSD2 Payments solution into the configuration of your application.',
      img: 'assets/icons/online-blue.svg',
    },
    {
      title: 'Heading 4',
      data: 'Initiating a bulk payment is easy. Add the PSD2 Payments solution into the configuration of your application.',
      img: 'assets/icons/cash-payment.svg',
    },
  ];

  return (
    <div id="solutionAvaileble">
      <h1 className="title text-center">Features</h1>
      <Row noGutters={true}>
        {props.data &&
          props.data.map((data) => (
            <Col className="d-sm-block" md={6} lg={3}>
              <Card className="solutionCard">
                <Card.Body className="no-pad">
                <img className="oval" src="assets/img/YBL-feature-icon-color.svg" alt="" />
                 {/* {data.featureName=="Instant"? <img className="oval" src="assets/img/YBL-feature-icon-color-Instant.svg" alt="" />:''}
                 {data.featureName=="Seamless"?   <img className="oval" src="assets/img/YBL-feature-icon-color-Seamless.svg" alt="" />:''}
                  {data.featureName=="Secure"?  <img className="oval" src="assets/img/YBL-feature-icon-color-Secure.svg" alt="" />:''}
                  {data.featureName=="Up to date"?   <img className="oval" src="assets/img/YBL-feature-icon-color-Seamless.svg" alt="" />:''}
                  {data.featureName=="Accuracy"?  <img className="oval" src="assets/img/YBL-feature-icon-color-Secure.svg" alt="" />:''}
                  {data.featureName=="Always On"?  <img className="oval" src="assets/img/YBL-feature-icon-color-Alwayson.svg" alt="" />:''}
                  {data.featureName=="Authorization"?  <img className="oval" src="assets/img/YBL-feature-icon-color.svg" alt="" />:''} */}
                  
                  <Card.Title className="scard-title">{data.featureName}</Card.Title>
                  <Card.Text className="scard-text">
                    <div dangerouslySetInnerHTML={{ __html: data.description }}></div>
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
          ))}
      </Row>
    </div>
  );
};

export default Features;

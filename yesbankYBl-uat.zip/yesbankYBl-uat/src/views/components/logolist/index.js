import React from 'react';
import { Container, Carousel } from 'react-bootstrap';

import './style.scss';

export default (props) => {
  return (
    <Container id="logoList">
      <h1 className="ptitle text-center">Partners</h1>
      <div className={'pCarousel'}>
        <Carousel controls={false} indicators={false} fade={true} interval={1000000}>
          <Carousel.Item>
            <div className="group">
              <img alt="Partner Logo" className="list-logo" src="assets/img/hylo-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/cashfree-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/finly-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/payu-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/open-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/zohobooks-logo.svg" />
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="group">
              <img alt="Partner Logo" className="list-logo" src="assets/icons/finly-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/payu-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/img/hylo-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/cashfree-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/open-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/zohobooks-logo.svg" />
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="group">
              <img alt="Partner Logo" className="list-logo" src="assets/icons/open-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/zohobooks-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/img/hylo-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/cashfree-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/finly-logo.svg" />
              <img alt="Partner Logo" className="list-logo" src="assets/icons/payu-logo.svg" />
            </div>
          </Carousel.Item>
        </Carousel>
      </div>
      {/* <h1 className="ctitle text-center">Customers</h1>
      <div className={'cCarousel'}>
      <Carousel  controls={false} indicators={false} fade={true} interval={1000}>
        <Carousel.Item>
          <div className="group">
            <img alt="Partner Logo" className="list-logo" src="assets/icons/cashfree-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/myntra-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/phonepe-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/dream11-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/Ola-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/WS-logo.svg" />
          </div>
       </Carousel.Item>
       <Carousel.Item>
          <div className="group">
            <img alt="Partner Logo" className="list-logo" src="assets/icons/WS-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/myntra-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/cashfree-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/phonepe-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/dream11-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/Ola-logo.svg" />
           
          </div>
       </Carousel.Item>
       <Carousel.Item>
          <div className="group">
          <img alt="Partner Logo" className="list-logo" src="assets/icons/phonepe-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/Ola-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/dream11-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/cashfree-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/myntra-logo.svg" />
            <img alt="Partner Logo" className="list-logo" src="assets/icons/WS-logo.svg" />
          </div>
       </Carousel.Item>
       </Carousel> 
       </div> */}
    </Container>
  );
};

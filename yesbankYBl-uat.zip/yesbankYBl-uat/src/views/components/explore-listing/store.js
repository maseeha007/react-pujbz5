import { GET_PRODUCTS_SUCCESS, GET_PRODUCTS_FAILURE, GET_BEYOND_DATA } from './constant';

const initialState = {
  products: [],
  error: null,
  beyondlist: [],
};

const solutionsReducer = (state = initialState, action) => {
  debugger;
  switch (action.type) {
    case GET_PRODUCTS_SUCCESS:
      return { ...state, products: action.data, error: null };
    case GET_PRODUCTS_FAILURE:
      return { ...state, products: [], error: action.error_message ? action.error_message : 'No Product available' };
    case GET_BEYOND_DATA:
      console.log('under store================>', action.data);
      return { ...state, beyondlist: action.data, error: null };

    default:
      return state;
  }
};

export default solutionsReducer;

import { all, call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { fetchSolutions, fetchTagsSolutions, getPartnerCategory } from './api';
import {
  GET_PRODUCTS_SUCCESS,
  GET_SOLUTIONS,
  GET_PRODUCTS_FAILURE,
  GET_TAGS_DATA,
  UPDATE_EXPLORE_LIST,
  GET_PARTNER_CATEGORY,
  GET_BEYOND_DATA,
} from './constant';
import { trackErrorEvent } from '../../../analytics';

export function* GetSolutionAsync() {
  try {
    const data = yield call(fetchSolutions);
    if (data.data.statusType == 'SUCCESS') {
      // debugger;
      // localStorage.setItem('products', JSON.stringify(data.data.response));
      yield put({ type: GET_PRODUCTS_SUCCESS, data: data.data.response });
    } else {
      ({ eventName: 'search btn clicked', errorName: 'No matching product found' });

      yield put({
        type: GET_PRODUCTS_FAILURE,
        error_message: data.data.message ? data.data.message : 'No matching product found.',
      });
    }
  } catch (error) {
    yield put({
      type: GET_PRODUCTS_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    yield put({
      type: GET_PRODUCTS_FAILURE,
      error_message: data.data.message ? data.data.message : 'Some Network Problem Occured',
    });
    trackErrorEvent({ eventName: 'search btn clicked', errorName: 'No matching product found' });
  }
}

export function* GetTagsDataAsync({ payload }) {
  try {
    const data = yield call(fetchTagsSolutions.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_PRODUCTS_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_PRODUCTS_FAILURE,
        error_message: 'No matching product found.',
      });
      trackErrorEvent({ eventName: 'search btn clicked', errorName: `No matching product found` });
    }
  } catch (error) {
    yield put({
      type: GET_PRODUCTS_FAILURE,
      error_message: 'No matching products found.',
    });
    trackErrorEvent({ eventName: 'search btn clicked', errorName: `No matching product found` });
  }
}

export function* updateTagsDataAsync({ payload }) {
  try {
    const data = yield call(fetchTagsSolutions.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_PRODUCTS_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_PRODUCTS_FAILURE,
        error_message: 'No matching product found.',
      });
      trackErrorEvent({ eventName: 'search btn clicked', errorName: `No matching product found` });
    }
  } catch (error) {
    yield put({
      type: GET_PRODUCTS_FAILURE,
      error_message: 'No matching products found.',
    });
    trackErrorEvent({ eventName: 'search btn clicked', errorName: `No matching product found` });
  }
}

export function* getPartnerCategoryAsync() {
  try {
    const data = yield call(getPartnerCategory);
    if (data.data.statusType == 'SUCCESS') {
      debugger;
      localStorage.setItem('products', JSON.stringify(data.data.response));
      yield put({ type: GET_BEYOND_DATA, data: data.data.response });

      // GET_BEYOND_DATA
    } else {
      ({ eventName: 'search btn clicked', errorName: 'No matching product found' });
      yield put({
        type: GET_BEYOND_DATA,
        data: [],
      });
    }
  } catch (error) {
    yield put({
      type: GET_BEYOND_DATA,
      data: [],
    });
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(GET_PARTNER_CATEGORY, getPartnerCategoryAsync),
    takeLatest(GET_SOLUTIONS, GetSolutionAsync),
    takeLatest(GET_TAGS_DATA, GetTagsDataAsync),
    takeLatest(UPDATE_EXPLORE_LIST, updateTagsDataAsync),
  ]);
}

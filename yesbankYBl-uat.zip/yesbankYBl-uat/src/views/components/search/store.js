import { GET_SEARCH} from "./constant";

const initialState = {
  results: [],
  error: null,
};

const searchReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_SEARCH:
        console.log("searchinreducer",action.payload);
      return { ...state, results: action.payload};
    default:
      return state;
  }
};

export default searchReducer;
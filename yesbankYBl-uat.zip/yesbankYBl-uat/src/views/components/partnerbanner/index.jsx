import React from 'react';
import { Button } from 'react-bootstrap';



import './style.scss';

const PartnerBanner = (props) => {
    let token = localStorage.getItem('token');

    return (
        !token ? (<div id="pbanner-section">
            <div className="content-section">
                <div className="partner-section">
                    <h1 className="ptitle ">Login to view detailed tech specifications & Subscribe</h1>
                    <p className="p-descrption">After Login you will be able to subscribe to range of YES BANK and Partners Products.
                        This will help you optimize your digital platform and also offer better digital experience to your customers.</p>
                    <Button className="submit-btn" onClick={props.checkLogin} variant="default">Login Now</Button>
                </div>
            </div>
            <div className="img-section">
                <img src="/assets/img/pdpbanner.svg" />
            </div>

        </div>) : <div />

    );
}

export default PartnerBanner


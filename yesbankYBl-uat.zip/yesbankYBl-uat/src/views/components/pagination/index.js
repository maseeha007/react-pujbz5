import React, {useState} from "react";
import { Pagination, Dropdown } from "react-bootstrap";
import "./style.scss";

function Index(props) {

  let prevPage= []
  let nextPage = []
  let lastPage = props.lastPage+1
  let currPage = props.pageNumber+1
  let [countN, setCount] = useState(10)

  for(let i = 1 ; i <3 ; i++ ) {
     if(currPage-i>0) {
       prevPage.push(currPage-i)
     }
  }

  for(let i = 1 ; i <3 ; i++ ) {
    if(currPage+i<=lastPage) {
      nextPage.push(currPage+i)
    }
 }
 let changeSize = (count) => {
  setCount(count)
  props.onChange(count)
 }
  
  return (
    <div className="pagination">
      <Dropdown>
        <Dropdown.Toggle variant="success" id="dropdown-basic">
          {countN}
        </Dropdown.Toggle>

        <Dropdown.Menu>
          <Dropdown.Item onClick={()=>{ changeSize(10)}}>10</Dropdown.Item>
          <Dropdown.Item onClick={()=>{ changeSize(20)}}>20</Dropdown.Item>
          <Dropdown.Item onClick={()=>{ changeSize(50)}}>50</Dropdown.Item>
          <Dropdown.Item onClick={()=>{ changeSize(100)}}>100</Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
      <Pagination>
        <Pagination.Prev className="nav-move" onClick={currPage-2 >-1 ? ()=> props.changePage(currPage-2): null } />
        {
          prevPage.reverse().map((item,index)=>{
            return <Pagination.Item key={index} onClick={()=>{ props.changePage(item-1)}}>{item}</Pagination.Item>
          })
        }
        
        <Pagination.Item active>{currPage}</Pagination.Item>
        {
          nextPage.map((item,index)=>{
            return <Pagination.Item key={index} onClick={()=>{ props.changePage(item-1)}} >{item}</Pagination.Item>
          })
        }
        <Pagination.Next className="nav-move" onClick={currPage<=(lastPage-1) ? () => props.changePage(currPage) : null } />
      </Pagination>
    </div>
  );
}

export default Index;

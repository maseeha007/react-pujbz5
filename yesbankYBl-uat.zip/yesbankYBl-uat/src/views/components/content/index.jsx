import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';



import './style.scss';

 const Content = (props) => {
  

  
  return (
    <div id="content-section">
      <h1 className="title text-center">{props.title}</h1>
     {props.title=="Functionalities"? <div className="row">
      <div className="col-sm-6 text-center">
        <img className="img-fluid" src="/assets/img/Functionalities.svg"/>
        </div>
        <div className="col-sm-6">
      <div className="content" noGutters={true} dangerouslySetInnerHTML={{__html: props?.data}}>
        </div>
        </div>
      </div>
      :<div className="content" noGutters={true} dangerouslySetInnerHTML={{__html: props?.data}}></div>
      }
      
     </div>
  );
}

export default Content


import React, { useState } from 'react';
import { useHistory, withRouter } from "react-router";
import { Link } from 'react-router-dom';
import { Navbar, Nav, Modal, Dropdown } from 'react-bootstrap';
import './style.scss';


function Header(props) {
  const history = useHistory();
  const [state, setState] = useState({ showSearch: false })
  const [login, setLogin] = useState(false);

  let username = localStorage.getItem('adminUserName')

  const logout = () => {
    localStorage.clear();
    props.history.push('/admins')
  }

  return (
    <React.Fragment>
      <Navbar expand="lg" className="no-pad" id="adminNav">
        <Navbar.Toggle className="no-border" id='toggle' aria-controls="ybl-navbar-nav" />
        <Navbar.Brand ><Link to="/"><img alt="logo" className="logo" src="/assets/img/logo.svg" /></Link></Navbar.Brand>

        <Navbar.Collapse className="justify-content-center nav-pills visible-md hidden-sm" id="ybl-navbar-nav">
        </Navbar.Collapse>
        { !props.isLogin ?
          <Nav className="icon-group">
            <Dropdown className="header-dropdown">
              <Dropdown.Toggle variant="link" id="dropdown-user">
                Welcome, {username == 'XXXXXXXXXXXXX' ? 'Admin' : username}
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item onClick={logout}>Logout</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </Nav> : null
        }
      </Navbar>
      <div className="clearfix"></div>
    </React.Fragment >
  );
}

export default withRouter(Header)